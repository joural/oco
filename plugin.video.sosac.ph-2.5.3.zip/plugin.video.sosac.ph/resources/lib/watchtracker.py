# -*- coding: UTF-8 -*-
"""
Follows the Kodi player and writes the watch history.

When the plugin starts playing a Sosac item it leaves a note in a window
property (what is being played and under which history key). This thread,
running in the add-on's service, sees the playback start, keeps the position
and saves it when playback stops, ends or another video takes over.
"""

import json
import os
import threading
import time
import traceback

import xbmc
import xbmcgui
import xbmcvfs

from .meta.history import History

PROPERTY = 'plugin.video.sosac.ph.playing'
POLL = 2                # seconds between two looks at the player
SAVE_EVERY = 60         # keep the position safe even if Kodi crashes
START_TIMEOUT = 180     # the note is dropped when nothing starts playing
MIN_POSITION = 10       # shorter than this was a mis-click, not watching


def log(message):
    xbmc.log('[plugin.video.sosac.ph history] %s' % message, xbmc.LOGINFO)


def history_path(addon):
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    if not os.path.isdir(profile):
        xbmcvfs.mkdirs(profile)
    return os.path.join(profile, 'history.db')


def announce(key, data):
    """Called by the plugin just before it hands Kodi the stream."""
    note = json.dumps({'key': key, 'data': data, 'at': time.time()}, ensure_ascii=False)
    xbmcgui.Window(10000).setProperty(PROPERTY, note)


class Tracker(threading.Thread):

    def __init__(self, addon):
        threading.Thread.__init__(self, name='sosac-watch-history')
        self.daemon = True
        self.addon = addon
        self.current = None

    def _history(self):
        return History(history_path(self.addon), log)

    def run(self):
        log('following playback')
        monitor = xbmc.Monitor()
        player = xbmc.Player()
        window = xbmcgui.Window(10000)
        while not monitor.waitForAbort(POLL):
            try:
                self._tick(player, window)
            except Exception:
                log(traceback.format_exc())
        if self.current:
            self._finish(window)

    def _tick(self, player, window):
        note = window.getProperty(PROPERTY)
        if note and (self.current is None or note != self.current['note']):
            if self.current and self.current['file']:
                self._finish(window, keep_note=True)
            try:
                parsed = json.loads(note)
            except ValueError:
                window.clearProperty(PROPERTY)
                return
            self.current = {'note': note, 'key': parsed.get('key'), 'data': parsed.get('data') or {},
                            'file': None, 'position': 0.0, 'total': 0.0,
                            'since': time.time(), 'saved': time.time()}
        current = self.current
        if current is None:
            return
        playing = player.isPlayingVideo()
        if playing:
            try:
                playing_file = player.getPlayingFile()
                position, total = player.getTime(), player.getTotalTime()
            except RuntimeError:        # between two videos
                return
            if current['file'] is None:
                current['file'] = playing_file
                log('playing %s' % current['data'].get('title'))
            elif playing_file != current['file']:
                self._finish(window)    # something else took over
                return
            if position > 0:
                current['position'], current['total'] = position, total
            if time.time() - current['saved'] > SAVE_EVERY and position >= MIN_POSITION:
                self._save(finished=False)
                current['saved'] = time.time()
        elif current['file'] is not None:
            self._finish(window)        # stopped or ended
        elif time.time() - current['since'] > START_TIMEOUT:
            log('%s never started playing' % current['data'].get('title'))
            self.current = None
            window.clearProperty(PROPERTY)

    def _save(self, finished=None):
        current = self.current
        history = self._history()
        try:
            return history.record(current['key'], current['data'], current['position'],
                                  current['total'], finished)
        finally:
            history.close()

    def _finish(self, window, keep_note=False):
        current, self.current = self.current, None
        if not current:
            return
        if current['file'] is not None and current['position'] >= MIN_POSITION:
            self.current = current
            row = self._save()
            self.current = None
            if row:
                log('%s: %s' % (current['data'].get('title'),
                                'watched' if row['watched'] else
                                'stopped at %d of %d s' % (row['position'], row['total'])))
        if not keep_note and window.getProperty(PROPERTY) == current['note']:
            window.clearProperty(PROPERTY)
        # lists that show watched ticks / percentages should show the new state
        if current['file'] is not None and xbmc.getInfoLabel('Container.FolderPath').startswith(
                'plugin://plugin.video.sosac.ph'):
            xbmc.executebuiltin('Container.Refresh')
