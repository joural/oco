# -*- coding: UTF-8 -*-
# /*
#  *  Metadata integration for plugin.video.sosac.ph
#  *
#  *  Turns the plain lists of the add-on into proper Kodi movie / TV show /
#  *  episode listings: content type, plot, ratings, cast, artwork, trailers.
#  *  The data comes from Sosac itself, then TMDb (with an API key), then
#  *  CSFD and IMDb for whatever is still missing. Trailers play through
#  *  SendToKodi (or the YouTube add-on).
#  *
#  *  This Program is free software; you can redistribute it and/or modify
#  *  it under the terms of the GNU General Public License as published by
#  *  the Free Software Foundation; either version 2, or (at your option)
#  *  any later version.
#  */

import math
import os
import re
import sys
import traceback
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

from . import xbmcutil
from .meta import imdb as imdb_source
from .meta.artcache import ArtCache
from .meta.cache import Cache
from .meta.history import History, RESUME_FROM, next_episode
from . import watchtracker
from .meta.engine import Engine, make_ref, ref_key
from .meta.textutil import localize_genres, to_int, to_text

MEDIA = ('movie', 'tvshow', 'episode')
# fields of a provider item worth keeping in the watch history
ITEM_FIELDS = ('title', 'name', 'names', 'year', 'imdb', 'csfd', 'genres', 'img', 'url', 'lang',
               'quality', 'mediatype', 'season', 'episode', 'show', 'show_names', 'rating')
TAG_COLORS = {'movie': 'FF7FB7E6', 'tvshow': 'FFE6B97F', 'episode': 'FF9FD99F'}
PAGE_SIZES = [0, 20, 40, 60, 100]
LIST_CACHE_SECONDS = 15 * 60
YOUTUBE_WATCH = 'https://www.youtube.com/watch?v=%s'
# Picture sizes asked from TMDb / IMDb. Kodi downloads, decodes and caches every
# picture the first time an item is shown, so on small devices (Raspberry Pi)
# big originals make scrolling slow. role -> (fast, balanced, best)
ART_SIZES = {
    'poster':    ('w342', 'w500', 'w780'),
    'fanart':    ('w780', 'w1280', 'original'),
    'landscape': ('w780', 'w1280', 'w1280'),
    'logo':      ('w300', 'w500', 'original'),
    'still':     ('w300', 'w780', 'original'),
    'profile':   ('w185', 'w185', 'h632'),
}
IMDB_WIDTHS = {'poster': (342, 500, 1000), 'fanart': (780, 1280, 1920), 'landscape': (780, 1280, 1280),
               'still': (300, 780, 1280), 'profile': (185, 185, 632), 'logo': (300, 500, 1000)}
ART_ROLES = {'poster': 'poster', 'tvshow.poster': 'poster', 'fanart': 'fanart',
             'tvshow.fanart': 'fanart', 'landscape': 'landscape', 'clearlogo': 'logo',
             'tvshow.clearlogo': 'logo'}
_TMDB_SIZE_RE = re.compile(r'(image\.tmdb\.org/t/p/)[^/]+/')
_IMDB_SIZE_RE = re.compile(r'\._V1_[^/]*?\.(jpe?g|png|webp)$')


def sized(url, role, quality):
    """The same TMDb / IMDb picture in the size chosen in the settings."""
    url = to_text(url)
    if not url or role not in ART_SIZES:
        return url
    if 'image.tmdb.org/t/p/' in url:
        return _TMDB_SIZE_RE.sub(lambda m: m.group(1) + ART_SIZES[role][quality] + '/', url, 1)
    if 'media-amazon.com' in url and _IMDB_SIZE_RE.search(url):
        return _IMDB_SIZE_RE.sub(r'._V1_UX%d_.\1' % IMDB_WIDTHS[role][quality], url)
    return url


# current yt-dlp (used by SendToKodi) refuses to run on older Python
SENDTOKODI_MIN_PYTHON = (3, 10)
# trailer players, see https://github.com/firsttris/plugin.video.sendtokodi
TRAILER_PLAYERS = {
    'sendtokodi': ('plugin.video.sendtokodi', 'plugin://plugin.video.sendtokodi/?url=%s'),
    'youtube': ('plugin.video.youtube', 'plugin://plugin.video.youtube/play/?video_id=%s'),
}

# string ids (resources/language/*/strings.po)
S_LOADING = 30240
S_NEXT_PAGE = 30241
S_TRAILER = 30242
S_REFRESH = 30243
S_NO_TRAILER = 30244
S_NEED_YOUTUBE = 30245
S_CACHE_CLEARED = 30246
S_TEST_TITLE = 30247
S_TEST_RUNNING = 30248
S_TRAILER_SUFFIX = 30249
S_CSFD_BLOCKED = 30252
S_TMDB_NO_KEY = 30261
S_TMDB_REJECTED = 30262
S_TMDB_DOWN = 30263
S_TMDB_BAD_KEY = 30264
S_PICTURES = 30271
S_CONTINUE = 30272
S_HISTORY = 30273
S_RESUME_FROM = 30274
S_FROM_START = 30275
S_MARK_WATCHED = 30276
S_MARK_UNWATCHED = 30277
S_REMOVE_HISTORY = 30278
S_NEXT_EPISODE = 30279
S_HISTORY_CLEARED = 30280
S_TAG_MOVIE = 30281
S_TAG_SHOW = 30282
S_TAG_EPISODE = 30283
S_NOTHING_HERE = 30284
S_STOP_SHOW = 30285
S_HEAD_SHOWS = 30289
S_HEAD_MOVIES = 30290

# ISO 639-1 -> the three letter codes Kodi uses for audio language flags
AUDIO_LANG = {'cs': 'cze', 'sk': 'slo', 'en': 'eng', 'de': 'ger', 'fr': 'fre', 'es': 'spa',
              'it': 'ita', 'pl': 'pol', 'ru': 'rus', 'hu': 'hun', 'ja': 'jpn', 'ko': 'kor',
              'cn': 'chi', 'zh': 'chi', 'nl': 'dut', 'pt': 'por', 'tr': 'tur', 'fi': 'fin',
              'no': 'nor', 'el': 'gre', 'hr': 'hrv', 'id': 'ind', 'vi': 'vie', 'sv': 'swe',
              'da': 'dan', 'uk': 'ukr'}


def _sort_key(text):
    """Alphabetical order that puts 'Č' next to 'C' (good enough for menus)."""
    import unicodedata
    text = unicodedata.normalize('NFKD', to_text(text).casefold())
    return ''.join(ch for ch in text if not unicodedata.combining(ch))


def log(message):
    xbmc.log('[plugin.video.sosac.ph metadata] %s' % message, xbmc.LOGINFO)


def _safe(call, *args):
    """Kodi's Python API differs between versions; one odd setter must not cost a listing."""
    try:
        call(*args)
        return True
    except Exception as e:
        xbmc.log('[plugin.video.sosac.ph metadata] %s%r failed: %s'
                 % (getattr(call, '__name__', call), args[:1], e), xbmc.LOGDEBUG)
        return False


def _info_tag(li):
    """The Kodi 20+ info tag with setters, or None on Kodi 19."""
    try:
        tag = li.getVideoInfoTag()
    except Exception:
        return None
    return tag if hasattr(tag, 'setTitle') and hasattr(tag, 'setCast') else None


def _outline(plot, limit=320):
    plot = plot.strip()
    if len(plot) <= limit:
        return plot
    cut = plot.rfind('. ', 0, limit)
    return plot[:cut + 1] if cut > 80 else plot[:limit].rsplit(' ', 1)[0] + '…'


def _resolution(quality):
    quality = to_text(quality).lower()
    if re.search(r'4k|uhd|2160', quality):
        return 3840, 2160
    if re.search(r'1080|fhd|full', quality):
        return 1920, 1080
    if re.search(r'hd|720', quality):
        return 1280, 720
    if re.search(r'sd|dvd|480|576', quality):
        return 720, 576
    return None


def _audio_languages(value):
    if isinstance(value, (list, tuple)):
        codes = [to_text(v).lower() for v in value]
    else:
        codes = re.findall(r'[a-z]{2}', to_text(value).lower())
    out = []
    for code in codes:
        code = AUDIO_LANG.get(code.strip())
        if code and code not in out:
            out.append(code)
    return out


def ratings_line(info):
    parts = []
    ratings = info.get('ratings') or {}
    if 'csfd' in ratings:
        parts.append('[B]ČSFD[/B] %d %%' % round(ratings['csfd']['rating'] * 10))
    if 'imdb' in ratings:
        parts.append('[B]IMDb[/B] %.1f' % ratings['imdb']['rating'])
    if 'tmdb' in ratings:
        parts.append('[B]TMDb[/B] %.1f' % ratings['tmdb']['rating'])
    return '  •  '.join(parts)


def apply_info(li, d):
    """
    Writes one normalized record to a ListItem, using the info tag setters on
    Kodi 20+ and setInfo() on Kodi 19.
    """
    ratings = d.get('ratings') or {}
    default = d.get('default_rating') or ''
    ids = dict((k, str(v)) for k, v in (d.get('ids') or {}).items() if v)
    default_id = 'imdb' if 'imdb' in ids else ''     # the default id is ListItem.IMDBNumber
    cast = [c for c in d.get('cast') or [] if c.get('name')]
    episode = d.get('mediatype') == 'episode'
    date = d.get('aired') or d.get('premiered') or ''

    tag = _info_tag(li)
    if tag is not None:
        _safe(tag.setMediaType, d.get('mediatype') or 'video')
        _safe(tag.setTitle, d.get('title') or '')
        if d.get('originaltitle'):
            _safe(tag.setOriginalTitle, d['originaltitle'])
        if d.get('year'):
            _safe(tag.setYear, int(d['year']))
        if d.get('plot'):
            _safe(tag.setPlot, d['plot'])
        if d.get('plotoutline'):
            _safe(tag.setPlotOutline, d['plotoutline'])
        if d.get('tagline'):
            _safe(tag.setTagLine, d['tagline'])
        if d.get('genres'):
            _safe(tag.setGenres, list(d['genres']))
        if d.get('countries'):
            _safe(tag.setCountries, list(d['countries']))
        if d.get('directors'):
            _safe(tag.setDirectors, list(d['directors']))
        if d.get('writers'):
            _safe(tag.setWriters, list(d['writers']))
        if d.get('studios'):
            _safe(tag.setStudios, list(d['studios']))
        if d.get('duration'):
            _safe(tag.setDuration, int(d['duration']))
        if d.get('mpaa'):
            _safe(tag.setMpaa, d['mpaa'])
        if date:
            _safe(tag.setFirstAired if episode else tag.setPremiered, date)
        for name, value in ratings.items():
            _safe(tag.setRating, float(value['rating']), int(value.get('votes') or 0),
                  name, name == default)
        if ids:
            _safe(tag.setUniqueIDs, ids, default_id)
        if ids.get('imdb') and not episode:
            _safe(tag.setIMDBNumber, ids['imdb'])
        if d.get('trailer'):
            _safe(tag.setTrailer, d['trailer'])
        if d.get('playcount'):
            _safe(tag.setPlaycount, int(d['playcount']))
        if d.get('tvshowtitle'):
            _safe(tag.setTvShowTitle, d['tvshowtitle'])
        if episode:
            _safe(tag.setSeason, int(d.get('season') or 0))
            _safe(tag.setEpisode, int(d.get('episode') or 0))
        if cast:
            try:
                actors = [xbmc.Actor(c['name'], c.get('role') or '', order, c.get('thumb') or '')
                          for order, c in enumerate(cast)]
                tag.setCast(actors)
            except Exception as e:
                xbmc.log('[plugin.video.sosac.ph metadata] cast failed: %s' % e, xbmc.LOGDEBUG)
        size = d.get('resolution')
        if size:
            try:
                tag.addVideoStream(xbmc.VideoStreamDetail(width=size[0], height=size[1]))
            except Exception:
                pass
        for code in d.get('audio') or []:
            try:
                tag.addAudioStream(xbmc.AudioStreamDetail(language=code))
            except Exception:
                pass
        return

    labels = {'mediatype': d.get('mediatype') or 'video', 'title': d.get('title') or ''}
    for key, source in (('originaltitle', 'originaltitle'), ('plot', 'plot'),
                        ('plotoutline', 'plotoutline'), ('tagline', 'tagline'),
                        ('mpaa', 'mpaa'), ('trailer', 'trailer'), ('tvshowtitle', 'tvshowtitle')):
        if d.get(source):
            labels[key] = d[source]
    for key, source in (('genre', 'genres'), ('country', 'countries'), ('director', 'directors'),
                        ('writer', 'writers'), ('studio', 'studios')):
        if d.get(source):
            labels[key] = list(d[source])
    if d.get('year'):
        labels['year'] = int(d['year'])
    if d.get('playcount'):
        labels['playcount'] = int(d['playcount'])
    if d.get('duration'):
        labels['duration'] = int(d['duration'])
    if date:
        labels['aired' if episode else 'premiered'] = date
    if episode:
        labels['season'] = int(d.get('season') or 0)
        labels['episode'] = int(d.get('episode') or 0)
    if default in ratings:
        labels['rating'] = float(ratings[default]['rating'])
        labels['votes'] = str(ratings[default].get('votes') or 0)
    if ids.get('imdb') and not episode:
        labels['imdbnumber'] = ids['imdb']
    _safe(li.setInfo, 'video', labels)
    for name, value in ratings.items():
        _safe(li.setRating, name, float(value['rating']), int(value.get('votes') or 0),
              name == default)
    if ids:
        _safe(li.setUniqueIDs, ids, default_id)
    if cast:
        _safe(li.setCast, [{'name': c['name'], 'role': c.get('role') or '',
                            'thumbnail': c.get('thumb') or '', 'order': order}
                           for order, c in enumerate(cast)])
    size = d.get('resolution')
    # the empty stream info silences a Kodi warning for plugin:// items (as before)
    _safe(li.addStreamInfo, 'video', {'width': size[0], 'height': size[1]} if size else {})
    for code in d.get('audio') or []:
        _safe(li.addStreamInfo, 'audio', {'language': code})


class MetadataUI(object):
    """
    Mixin for the add-on's Kodi presenter (XBMCSosac). When metadata is
    switched off in the settings every method falls through to the original
    behaviour.
    """

    _meta_engine_obj = None
    _meta_history_obj = False
    _meta_hist = {}
    _meta_tag_labels = False
    _meta_kinds = ()
    _meta_pictures_obj = False
    _meta_addons = None
    _meta_route = None
    _meta_page = 1

    # -- settings ---------------------------------------------------------

    def meta_setting(self, key, default=''):
        try:
            value = self.addon.getSetting(key)
        except Exception:
            value = ''
        return default if value in (None, '') else value

    def meta_bool(self, key, default=True):
        return self.meta_setting(key, 'true' if default else 'false') == 'true'

    def meta_enum(self, key, values, default=0):
        index = to_int(self.meta_setting(key, default), default)
        return values[index] if 0 <= index < len(values) else values[default]

    def meta_on(self):
        return self.meta_bool('meta-enabled', True)

    def meta_items_only(self):
        """
        "Items only": the add-on looks nothing up. It hands Kodi typed items
        (movie / tvshow / episode) with titles, years and IMDb numbers and
        leaves ratings, trailers etc. to whatever the skin brings along
        (e.g. script.nimbus.helper, which works from ListItem.IMDBNumber).
        """
        return self.meta_enum('meta-mode', ['lookup', 'items']) == 'items'

    def meta_language(self):
        lang = self.meta_enum('meta-lang', ['auto', 'sk', 'cs', 'en'])
        if lang == 'auto':
            try:
                lang = xbmc.getLanguage(xbmc.ISO_639_1)
            except Exception:
                lang = 'en'
        return lang if lang in ('sk', 'cs', 'en') else 'en'

    def meta_config(self):
        lookups = not self.meta_items_only()
        return {
            'lang': self.meta_language(),
            'plot_source': self.meta_enum('meta-plot-source', ['auto', 'csfd', 'imdb', 'tmdb']),
            'use_csfd': lookups and self.meta_bool('meta-use-csfd', True),
            'use_imdb': lookups and self.meta_bool('meta-use-imdb', True),
            'tmdb_key': self.meta_setting('meta-tmdb-key').strip() if lookups else '',
            'tmdb_search': self.meta_bool('meta-tmdb-search', True),
            'translate': lookups and self.meta_bool('meta-translate', True),
            'translator': self.meta_enum('meta-translator', ['google', 'deepl', 'mymemory']),
            'deepl_key': self.meta_setting('meta-deepl-key').strip(),
            'accept_related': self.meta_bool('meta-accept-related', False),
            'default_rating': self.meta_enum('meta-rating', ['auto', 'csfd', 'imdb']),
            'cache_days': to_int(self.meta_setting('meta-cache-days', 30), 30),
            'budget': to_int(self.meta_setting('meta-budget', 25), 25),
            'workers': 4,
            'client': self._meta_client(),
        }

    def _meta_client(self):
        kodi = ''
        try:
            kodi = xbmc.getInfoLabel('System.BuildVersion').split(' ')[0]
        except Exception:
            pass
        return 'Kodi/%s %s/%s' % (kodi or '?', self.addon.getAddonInfo('id'),
                                  self.addon.getAddonInfo('version'))

    def meta_art_quality(self):
        """0 fast (small devices), 1 balanced (default), 2 best (big originals)."""
        quality = to_int(self.meta_setting('meta-art-quality', 1), 1)
        return quality if 0 <= quality <= 2 else 1

    def meta_sized(self, record, art):
        """Applies the "Artwork quality" setting to the art and the cast photos."""
        quality = self.meta_art_quality()
        poster = art.get('poster') or art.get('tvshow.poster')
        out = {}
        for key, url in art.items():
            role = ART_ROLES.get(key)
            if role is None:            # thumb / icon: the poster, or an episode still
                role = 'poster' if url == poster else 'still'
            out[key] = sized(url, role, quality)
        if record.get('cast'):
            record['cast'] = [dict(c, thumb=sized(c.get('thumb'), 'profile', quality))
                              for c in record['cast']]
        return record, out

    # -- watch history ----------------------------------------------------

    def meta_history(self):
        if self._meta_history_obj is False:
            self._meta_history_obj = None
            if self.meta_bool('history-enabled', True):
                try:
                    store = History(watchtracker.history_path(self.addon), log)
                    self._meta_history_obj = store if store.ok else None
                except Exception:
                    log('no watch history: %s' % traceback.format_exc())
        return self._meta_history_obj

    def meta_tag(self, kind):
        """A coloured 'Movie' / 'TV show' / 'Episode' label part."""
        string = {'movie': S_TAG_MOVIE, 'tvshow': S_TAG_SHOW, 'episode': S_TAG_EPISODE}[kind]
        return '[COLOR %s][%s][/COLOR]' % (TAG_COLORS[kind], self.meta_string(string))

    @staticmethod
    def _meta_fill(text, value):
        """'Resume from %s' + value; a translation without %s must not break playback."""
        return text.replace('%s', value) if '%s' in text else '%s %s' % (text, value)

    @staticmethod
    def _clock(seconds):
        seconds = int(seconds or 0)
        return '%d:%02d:%02d' % (seconds // 3600, seconds // 60 % 60, seconds % 60)

    def root(self):
        if self.meta_history() is not None:
            for action, string, icon in (('continue', S_CONTINUE, 'DefaultInProgressShows.png'),
                                         ('history', S_HISTORY, 'DefaultRecentlyAddedMovies.png')):
                params = self.params()
                params['meta'] = action
                li = xbmcgui.ListItem('[B]%s[/B]' % self.meta_string(string))
                li.setArt({'icon': icon, 'thumb': icon})
                xbmcplugin.addDirectoryItem(int(sys.argv[1]), xbmcutil._create_plugin_url(params),
                                            li, True)
        return super(MetadataUI, self).root()

    def _meta_history_item(self, row, label):
        data = row['data']
        item = self.provider.video_item()
        item.update(dict((k, v) for k, v in (data.get('item') or {}).items() if v is not None))
        item['title'] = label
        item['keep_label'] = True
        item['mediatype'] = data.get('kind') or item.get('mediatype') or 'movie'
        if data.get('ctx'):
            item['ctx'] = data['ctx']
        if data.get('show_list'):
            item['show_list'] = data['show_list']
        remove = {'meta': 'history-remove', 'key': row['key']}
        item['menu'] = {self.meta_string(S_REMOVE_HISTORY): remove}
        if data.get('show_key'):
            item['menu'][self.meta_string(S_STOP_SHOW)] = {'meta': 'history-remove-show',
                                                          'show': data['show_key']}
        return item

    def _meta_history_label(self, data, prefix=''):
        kind = data.get('kind') or 'movie'
        return '%s %s%s' % (self.meta_tag(kind), prefix, to_text(data.get('title')))

    def _meta_continue_items(self):
        history = self.meta_history()
        rows = []
        for row in history.unfinished():
            label = self._meta_history_label(row['data']) + ' [COLOR FFAAAAAA](%s)[/COLOR]' % \
                self._clock(row['position'])
            rows.append((row['updated'], self._meta_history_item(row, label)))
        unfinished = set(r['key'] for r in history.unfinished())
        for row in history.shows(limit=15):
            data = row['data']
            if row['key'] in unfinished or not row['watched'] or not data.get('show_list'):
                continue
            try:
                episodes = self.provider.list_episodes(data['show_list'])
            except Exception:
                log('next episode of %s: %s' % (data.get('show_title'), traceback.format_exc()))
                continue
            following = next_episode(episodes, row['season'], row['episode'],
                                     history.watched_in_show(row['show']))
            if not following:
                continue
            item = self._meta_history_item(row, '')
            for key in ('url', 'season', 'episode', 'name', 'img'):
                item[key] = following.get(key)
            item['title'] = '%s %s%s - %02dx%02d - %s' % (
                self.meta_tag('episode'), '[B]%s:[/B] ' % self.meta_string(S_NEXT_EPISODE),
                to_text(data.get('show_title')), to_int(following.get('season')),
                to_int(following.get('episode')), to_text(following.get('name')))
            item['menu'] = {self.meta_string(S_STOP_SHOW): {'meta': 'history-remove-show',
                                                            'show': row['show']}}
            rows.append((row['updated'], item))
        rows.sort(key=lambda r: -r[0])
        return [item for _, item in rows]

    def _meta_history_items(self):
        items = []
        for row in self.meta_history().recent(100):
            prefix = ''
            if row['watched']:
                prefix = '[COLOR FF9FD99F]\u2713[/COLOR] '
            elif row['position'] >= RESUME_FROM:
                prefix = '[COLOR FFAAAAAA](%s)[/COLOR] ' % self._clock(row['position'])
            items.append(self._meta_history_item(row, self._meta_history_label(row['data'], prefix)))
        return items

    def _meta_show_history(self, action):
        handle = int(sys.argv[1])
        if self.meta_history() is None:
            return xbmcplugin.endOfDirectory(handle)
        try:
            self.provider.list_cache = self.meta_engine().cache
            self.provider.list_cache_seconds = LIST_CACHE_SECONDS
        except Exception:
            pass
        items = self._meta_continue_items() if action == 'continue' else self._meta_history_items()
        if not items:
            li = xbmcgui.ListItem(self.meta_string(S_NOTHING_HERE))
            xbmcplugin.addDirectoryItem(handle, '', li, False)
        else:
            self.list(items)
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)

    def _meta_history_data(self, item):
        """What the history keeps about the item being played."""
        url = to_text(item['url'])
        stored = None
        try:
            stored = self.meta_engine().cache.get('play:' + url)
        except Exception:
            pass
        if stored and stored.get('item'):
            stored = dict(stored, url=url)
            if stored.get('kind') == 'episode' and not stored.get('show_list') and \
                    stored.get('show_title'):
                # e.g. from "TV Shows - Recently added": find the show, so that
                # Continue watching can offer its next episode
                names = list((stored['item'].get('show_names') or {}).values())
                try:
                    show_list = self.provider.find_series(names + [stored['show_title']])
                except Exception:
                    log('show lookup: %s' % traceback.format_exc())
                    show_list = None
                if show_list:
                    stored['show_list'] = stored['show_key'] = show_list
            return stored
        title = to_text((item.get('info') or {}).get('title')) or url
        return {'kind': 'movie', 'title': title, 'url': url,
                'item': {'url': url, 'title': title, 'mediatype': 'movie'}}

    def _meta_resume(self, key):
        """Asks where to start. Returns seconds, 0, or None when the user cancelled."""
        row = self.meta_history().get(key) if self.meta_history() is not None else None
        if not row or row['watched'] or row['position'] < RESUME_FROM:
            return 0
        choice = xbmcgui.Dialog().contextmenu([
            self._meta_fill(self.meta_string(S_RESUME_FROM), self._clock(row['position'])),
            self.meta_string(S_FROM_START)])
        if choice < 0:
            return None
        return row['position'] if choice == 0 else 0

    def meta_pictures(self):
        """The local picture store, or None when pictures are left to Kodi."""
        if self._meta_pictures_obj is False:
            self._meta_pictures_obj = None
            if self.meta_bool('meta-art-download', True) and not self.meta_items_only():
                try:
                    profile = xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
                    store = ArtCache(os.path.join(profile, 'pictures'),
                                     to_int(self.meta_setting('meta-art-keep', 24), 24), log)
                    self._meta_pictures_obj = store if store.ok else None
                except Exception:
                    log('no picture store: %s' % traceback.format_exc())
        return self._meta_pictures_obj

    def _meta_download_pictures(self, batch, arts):
        """
        Downloads the pictures of this page (they are what makes scrolling slow
        when Kodi has to fetch them itself) and points the items at the files.
        """
        store = self.meta_pictures()
        if store is None or not arts:
            return
        urls = []
        for art in arts:
            for url in art.values():
                if url not in urls:
                    urls.append(url)
        state = {'dialog': None}
        monitor = xbmc.Monitor()
        heading = self.addon.getAddonInfo('name')
        message = self.meta_string(S_PICTURES)

        def progress(done, total):
            if state['dialog'] is None:
                state['dialog'] = xbmcgui.DialogProgressBG()
                state['dialog'].create(heading, message)
            state['dialog'].update(int(done * 100 / max(total, 1)), heading,
                                   '%s %d/%d' % (message, done, total))
            return not monitor.abortRequested()

        try:
            store.fetch_many(urls, budget=min(30, to_int(self.meta_setting('meta-budget', 25), 25)),
                             progress=progress)
        finally:
            if state['dialog'] is not None:
                state['dialog'].close()
        for (url, li, folder), art in zip(batch, arts):
            local = store.localize(art)
            if local != art:
                li.setArt(local)
        store.cleanup()

    def meta_engine(self):
        if self._meta_engine_obj is None:
            path = None
            try:
                profile = xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
                if not os.path.isdir(profile):
                    xbmcvfs.mkdirs(profile)
                path = os.path.join(profile, 'metadata.db')
            except Exception as e:
                log('no profile folder (%s), metadata is cached in memory only' % e)
            self._meta_engine_obj = Engine(self.meta_config(), Cache(path, log), log)
            log(self._meta_engine_obj.describe())
        return self._meta_engine_obj

    def _meta_report_tmdb(self, engine):
        """Says out loud why TMDb gave nothing (once in a while, not on every page)."""
        if self.meta_items_only():
            return
        problem = engine.tmdb_problem
        if not problem:
            return
        log('TMDb: %s %s (%d requests this run)' % (problem, engine.tmdb_error, engine.tmdb_calls))
        message = {'nokey': S_TMDB_NO_KEY, 'rejected': S_TMDB_REJECTED,
                   'badkey': S_TMDB_BAD_KEY}.get(problem, S_TMDB_DOWN)
        note = 'note:tmdb:' + problem
        if engine.cache.get(note, max_age=6 * 3600 if problem == 'nokey' else 600):
            return
        engine.cache.set(note, True)
        xbmcgui.Dialog().notification(self.addon.getAddonInfo('name'), self.meta_string(message),
                                      xbmcgui.NOTIFICATION_WARNING, 8000, False)

    def meta_string(self, string_id):
        return self.addon.getLocalizedString(string_id)

    def meta_notify(self, message):
        xbmcgui.Dialog().notification(self.addon.getAddonInfo('name'), message,
                                      xbmcgui.NOTIFICATION_INFO, 4000, False)

    # -- routing ----------------------------------------------------------

    def run(self, params):
        params = dict(params)
        self._meta_page = max(1, to_int(params.pop('page', 1), 1))
        self._meta_route = dict(params)
        if 'meta' in params:
            return self.meta_action(params)
        try:
            if self.meta_on() and self._meta_page_size():
                # paging re-reads the same big list for every page: keep it for a while
                self.provider.list_cache = self.meta_engine().cache
                self.provider.list_cache_seconds = LIST_CACHE_SECONDS
        except Exception:
            log('list cache not available: %s' % traceback.format_exc())
        return super(MetadataUI, self).run(params)

    def search(self, keyword):
        # remember the keyword so "next page" does not ask for it again
        only = (self._meta_route or {}).get('only')
        self._meta_route = dict(self.params(), search=keyword)
        if only in ('movie', 'tvshow'):
            self._meta_route['only'] = only
        # movies and TV shows come together: say which is which
        self._meta_tag_labels = True
        items = self.provider.search(keyword)
        if only in ('movie', 'tvshow'):
            items = [i for i in items if i.get('mediatype') == only]
        self.list(items)
        return xbmcplugin.endOfDirectory(int(sys.argv[1]))

    def _meta_type_word(self, kind):
        return self.meta_string({'movie': S_TAG_MOVIE, 'tvshow': S_TAG_SHOW,
                                 'episode': S_TAG_EPISODE}[kind])

    def _meta_search_heading(self, kind, count):
        """'— Seriály (2) —': groups search results; opens only that kind."""
        text = self._meta_fill(self.meta_string(S_HEAD_SHOWS if kind == 'tvshow' else S_HEAD_MOVIES),
                               str(count))
        li = xbmcgui.ListItem('[B][COLOR %s]\u2014 %s \u2014[/COLOR][/B]' % (TAG_COLORS[kind], text))
        icon = 'DefaultTVShows.png' if kind == 'tvshow' else 'DefaultMovies.png'
        li.setArt({'icon': icon, 'thumb': icon, 'poster': icon})
        route = dict(self._meta_route or {})
        route.pop('page', None)
        route['only'] = kind
        return xbmcutil._create_plugin_url(route), li, True

    def _meta_with_headings(self, batch, all_media):
        """Puts a heading in front of the TV shows and of the movies of a search page."""
        if not self._meta_tag_labels or (self._meta_route or {}).get('only'):
            return batch
        totals = {}
        for item in all_media:
            totals[item['mediatype']] = totals.get(item['mediatype'], 0) + 1
        if len(totals) < 2:
            return batch                # one kind only: the tags say enough
        out, current = [], None
        for entry, kind in zip(batch, self._meta_kinds):
            if kind != current and kind in ('tvshow', 'movie'):
                out.append(self._meta_search_heading(kind, totals.get(kind, 0)))
                current = kind
            out.append(entry)
        return out

    def meta_action(self, params):
        action = params.get('meta')
        if action == 'trailer':
            return self._meta_trailer(params)
        if action in ('continue', 'history'):
            return self._meta_show_history(action)
        if action in ('history-remove', 'history-remove-show', 'mark-watched', 'mark-unwatched',
                      'clear-history'):
            history = self.meta_history()
            if history is not None:
                if action == 'history-remove':
                    history.remove(params.get('key'))
                elif action == 'history-remove-show':
                    history.remove_show(params.get('show'))
                elif action == 'clear-history':
                    history.clear()
                    self.meta_notify(self.meta_string(S_HISTORY_CLEARED))
                else:
                    item = {'url': params.get('url'), 'info': {'title': params.get('title')}}
                    history.set_watched('v:' + to_text(params.get('url')),
                                        action == 'mark-watched', self._meta_history_data(item))
            xbmc.executebuiltin('Container.Refresh')
            return
        if action == 'refresh':
            self.meta_engine().forget(self._meta_ref_from_params(params))
            xbmc.executebuiltin('Container.Refresh')
        elif action == 'clear':
            self.meta_engine().cache.clear()
            if self.meta_pictures() is not None:
                self.meta_pictures().cleanup(force=True)
            self.meta_notify(self.meta_string(S_CACHE_CLEARED))
        elif action == 'test':
            self._meta_test()

    def _meta_test(self):
        self.meta_notify(self.meta_string(S_TEST_RUNNING))
        engine = self.meta_engine()
        lines = []
        for name, ok, detail in engine.diagnose():
            lines.append('[COLOR %s]%s[/COLOR]  [B]%s[/B][CR]      %s'
                         % ('green' if ok else 'red', 'OK' if ok else 'FAIL', name, detail))
        engine.cache.delete('net:paused')
        cfg = engine.cfg
        lines.append('')
        lines.append('language: %s, plot source: %s, translator: %s, cached entries: %d'
                     % (cfg['lang'], cfg['plot_source'],
                        engine.translator.engine if cfg['translate'] else 'off',
                        engine.cache.count()))
        xbmcgui.Dialog().textviewer(self.meta_string(S_TEST_TITLE), '[CR]'.join(lines))

    # -- listing ----------------------------------------------------------

    def _meta_page_size(self):
        return self.meta_enum('meta-page-size', PAGE_SIZES, 2)

    def _meta_ui_language(self):
        try:
            lang = xbmc.getLanguage(xbmc.ISO_639_1)
        except Exception:
            lang = 'en'
        return lang if lang in ('sk', 'cs', 'en') else 'en'

    def _meta_translate_genres(self, items):
        """Genre menu: Sosac's English keys in the user's language, sorted again."""
        genres = [i for i in items if i.get('genre_key')]
        if not genres:
            return items
        lang = self._meta_ui_language()
        for item in genres:
            translated = localize_genres([item['genre_key']], lang)
            if translated:
                item['title'] = translated[0]
        others = [i for i in items if not i.get('genre_key')]
        return others + sorted(genres, key=lambda i: _sort_key(i['title']))

    def list(self, items):
        items = self._meta_translate_genres(list(items))
        if not self.meta_on():
            if self._meta_tag_labels:
                items = [dict(i, title='%s %s' % (self.meta_tag(i['mediatype']), to_text(i['title'])))
                         if i.get('mediatype') in MEDIA else i for i in items]
            return super(MetadataUI, self).list(items)
        items = [item for item in items]
        media = [item for item in items if item.get('mediatype') in MEDIA]
        if not media:
            return super(MetadataUI, self).list(items)
        try:
            prepared = self._meta_prepare(media)
        except Exception:
            # never lose a listing because of metadata
            log('falling back to the plain list: %s' % traceback.format_exc())
            return super(MetadataUI, self).list(items)

        handle = int(sys.argv[1])
        batch, content, page, pages = prepared
        batch = self._meta_with_headings(batch, media)
        if page == 1:
            media_ids = set(id(item) for item in media)
            super(MetadataUI, self).list([i for i in items if id(i) not in media_ids])
        xbmcplugin.addDirectoryItems(handle, batch, len(batch))
        if page < pages:
            route = dict(self._meta_route or self.params())
            route['page'] = str(page + 1)
            li = xbmcgui.ListItem('%s (%d/%d)' % (self.meta_string(S_NEXT_PAGE), page + 1, pages))
            li.setArt({'icon': 'DefaultFolder.png'})
            li.setProperty('SpecialSort', 'bottom')
            xbmcplugin.addDirectoryItem(handle, xbmcutil._create_plugin_url(route), li, True)
        xbmcplugin.setContent(handle, content)
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
        if content == 'episodes':
            xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_EPISODE)
        else:
            xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
            xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
            xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_VIDEO_RATING)

    def _meta_prepare(self, media):
        kinds = set(item['mediatype'] for item in media)
        if len(kinds) > 1:
            content = 'videos'          # search results, history: movies and shows together
        else:
            content = {'episode': 'episodes', 'tvshow': 'tvshows'}.get(kinds.pop(), 'movies')

        size = self._meta_page_size()
        pages = int(math.ceil(len(media) / float(size))) if size else 1
        page = min(self._meta_page, max(pages, 1))
        chunk = media[(page - 1) * size:page * size] if size else media

        engine = self.meta_engine()
        context = None
        if content == 'episodes':
            context = engine.cache.get('ctx:' + to_text((self._meta_route or {}).get('list')))
        self._meta_hist = {}
        if self.meta_history() is not None:
            self._meta_hist = self.meta_history().get_many(
                ['v:' + to_text(item.get('url')) for item in chunk if item.get('url')])

        refs, seasons = [], []
        for item in chunk:
            ref = self._meta_ref(item, context)
            if not engine.can_lookup(ref):
                continue
            refs.append(ref)
            if item['mediatype'] == 'episode':
                seasons.append((ref, item.get('season')))
        titles, episodes = self._meta_fetch(engine, refs, seasons)

        batch, side, arts = [], {}, []
        self._meta_kinds = [item['mediatype'] for item in chunk]
        for item in chunk:
            batch.append(self._meta_build(engine, item, context, titles, episodes, side, arts))
        engine.cache.set_many(side)
        try:
            self._meta_download_pictures(batch, arts)
        except Exception:
            log('pictures: %s' % traceback.format_exc())
        return batch, content, page, pages

    def _meta_ref(self, item, context=None):
        """The title to look up: the movie/show itself, or the show of an episode."""
        if item['mediatype'] == 'episode':
            context = item.get('ctx') or context or {}
            return make_ref(item.get('imdb') or context.get('imdb'),
                            item.get('csfd') or context.get('csfd'), 'tvshow',
                            item.get('show') or context.get('title') or '',
                            context.get('year'), context.get('genres'),
                            item.get('show_names') or context.get('names'),
                            context.get('plot'))
        # movies only carry their genres in 'plot'; a TV show's 'plot' is Sosac's description
        plot = item.get('plot') if item['mediatype'] == 'tvshow' else ''
        return make_ref(item.get('imdb'), item.get('csfd'), item['mediatype'],
                        item.get('name') or item.get('title'), item.get('year'),
                        item.get('genres'), item.get('names'), plot)

    @staticmethod
    def _meta_ref_params(ref):
        """A ref as plugin URL parameters (refresh / trailer actions)."""
        return {'imdb': ref.get('imdb') or '', 'csfd': ref.get('csfd') or '',
                'mt': ref.get('mediatype') or 'movie', 'title': ref.get('title') or '',
                'year': str(ref.get('year') or ''), 'names': '|'.join(ref.get('names') or [])}

    @staticmethod
    def _meta_ref_from_params(params):
        names = [n for n in to_text(params.get('names')).split('|') if n]
        return make_ref(params.get('imdb'), params.get('csfd'), params.get('mt') or 'movie',
                        params.get('title'), params.get('year'), None, names)

    def _meta_fetch(self, engine, refs, seasons):
        state = {'dialog': None}
        monitor = xbmc.Monitor()
        heading = self.addon.getAddonInfo('name')
        message = self.meta_string(S_LOADING)

        def progress(done, total):
            if state['dialog'] is None:
                state['dialog'] = xbmcgui.DialogProgressBG()
                state['dialog'].create(heading, message)
            state['dialog'].update(int(done * 100 / max(total, 1)), heading,
                                   '%s %d/%d' % (message, done, total))
            return not monitor.abortRequested()

        try:
            return engine.get_many(refs, seasons, progress)
        finally:
            if state['dialog'] is not None:
                state['dialog'].close()
            if any('csfd' in host for host in engine.blocked):
                # said once per pause, so the missing CSFD rating is no mystery
                self.meta_notify(self.meta_string(S_CSFD_BLOCKED))
            try:
                self._meta_report_tmdb(engine)
            except Exception:
                log('report: %s' % traceback.format_exc())

    def _meta_build(self, engine, item, context, titles, episodes, side, arts=None):
        """Returns (url, listitem, isFolder) for one movie, show or episode."""
        kind = item['mediatype']
        ref = self._meta_ref(item, context)
        info = titles.get(ref_key(ref)) if engine.can_lookup(ref) else None
        if info is None:
            info = engine.merge(ref, {})
        info = dict(info)
        url = to_text(item.get('url'))
        image = to_text(item.get('img'))

        if kind == 'episode':
            season, number = to_int(item.get('season')), to_int(item.get('episode'))
            extra = (episodes.get((ref_key(ref), str(season))) or {}).get(str(number)) or {}
            record = self._meta_episode_record(item, info, extra, season, number)
            art = self._meta_art(info, image,
                                 imdb_source.image(extra.get('thumb'), width=1280) or '')
            ctx = item.get('ctx') or context or {}
            show_list = to_text(item.get('show_list')) or \
                (to_text((self._meta_route or {}).get('list')) if context else '')
            show_title = to_text(item.get('show')) or to_text(ctx.get('title')) or \
                to_text(ref.get('title'))
            side['play:' + url] = {
                'kind': 'episode', 'ref': ref, 'season': season, 'episode': number,
                'name': to_text(item.get('name')), 'img': image,
                'item': dict(self._meta_item_copy(item), show=show_title),
                'ctx': ctx or None, 'show_list': show_list, 'show_title': show_title,
                'show_key': show_list or ('title:' + show_title.lower() if show_title else ''),
                'title': '%s - %02dx%02d - %s' % (show_title, season, number,
                                                  to_text(item.get('name')))}
        else:
            record = self._meta_title_record(item, info)
            art = self._meta_art(info, image, kind=kind)
            if kind == 'movie':
                name = to_text(item.get('name') or item.get('title'))
                year = to_int(item.get('year'))
                side['play:' + url] = {'kind': 'movie', 'ref': ref, 'img': image,
                                       'item': self._meta_item_copy(item),
                                       'title': '%s (%d)' % (name, year) if year else name}
            else:
                side['ctx:' + url] = {'imdb': ref.get('imdb'), 'csfd': ref.get('csfd'),
                                      'title': ref.get('title'), 'year': ref.get('year'),
                                      'names': ref.get('names'), 'genres': ref.get('genres'),
                                      'plot': ref.get('plot'), 'img': image}

        label = to_text(item.get('title'))
        if kind != 'tvshow':
            # same rule as the original list: show the size only when it is known
            size = to_text(item.get('size'))
            if size and size != self.provider.video_item()['size']:
                label = '%s (%s)' % (label, size)
        if kind != 'episode' and self.meta_bool('meta-clean-labels', False) and item.get('name') \
                and not item.get('keep_label'):
            label = to_text(item['name'])
        tagged = self._meta_tag_labels and not item.get('keep_label')
        if tagged:
            year = to_int(item.get('year'))
            if kind == 'tvshow' and year and '(%d)' % year not in label:
                label = '%s (%d)' % (label, year)
            label = '%s %s' % (self.meta_tag(kind), label)
            # many skins show the Title instead of the label (poster / wall views)
            record['title'] = '%s %s' % (self.meta_tag(kind), to_text(record.get('title')))

        seen = self._meta_hist.get('v:' + url) if kind != 'tvshow' else None
        if seen and seen['watched']:
            record['playcount'] = 1
        elif seen and seen['position'] >= RESUME_FROM and '(%s)' % self._clock(seen['position']) \
                not in label:
            label += ' [COLOR FFAAAAAA](%s)[/COLOR]' % self._clock(seen['position'])

        li = xbmcgui.ListItem(label, offscreen=True)
        if tagged:
            li.setLabel2(self._meta_type_word(kind))
        record, art = self.meta_sized(record, art)
        apply_info(li, record)
        li.setArt(art)
        if arts is not None:
            arts.append(art)
        # Skin helpers look the focused item up by these (script.nimbus.helper reads
        # ListItem.IMDBNumber, then Property(imdb) / Property(tmdb)); for an episode
        # it is the show's number, so the show's ratings appear.
        known = info.get('ids') or {}
        if known.get('imdb'):
            li.setProperty('imdb', str(known['imdb']))
        if known.get('tmdb'):
            li.setProperty('tmdb', str(known['tmdb']))

        params = self.params()
        menu = {}
        if kind == 'tvshow':
            params.update({'list': url})
        else:
            params.update({'play': url})
            li.setProperty('IsPlayable', 'true')
            if '!download' not in self.provider.capabilities():
                down = self.params()
                down.update({'title': to_text(item.get('title')), 'down': url})
                menu[xbmc.getLocalizedString(33003)] = down
        for title, value in (item.get('menu') or {}).items():
            menu[xbmcutil.localize(to_text(title), self.addon)] = value
        entries = [] if kind == 'tvshow' else [(xbmc.getLocalizedString(13347), 'Action(Queue)')]
        entries += self._meta_menu_entries(menu)
        if record.get('trailer'):
            entries.append((self.meta_string(S_TRAILER), 'PlayMedia(%s)' % record['trailer']))
        if kind != 'tvshow' and self.meta_history() is not None:
            mark = {'meta': 'mark-unwatched' if seen and seen['watched'] else 'mark-watched',
                    'url': url, 'title': to_text(item.get('name') or item.get('title'))}
            entries.append((self.meta_string(S_MARK_UNWATCHED if seen and seen['watched']
                                             else S_MARK_WATCHED),
                            'RunPlugin(%s)' % xbmcutil._create_plugin_url(mark)))
        if engine.can_lookup(ref) and not self.meta_items_only():
            refresh = self.params()
            refresh.update(self._meta_ref_params(ref))
            refresh['meta'] = 'refresh'
            entries.append((self.meta_string(S_REFRESH),
                            'RunPlugin(%s)' % xbmcutil._create_plugin_url(refresh)))
        if entries:
            li.addContextMenuItems(entries)
        return xbmcutil._create_plugin_url(params), li, kind == 'tvshow'

    @staticmethod
    def _meta_item_copy(item):
        return dict((k, item[k]) for k in ITEM_FIELDS if item.get(k) not in (None, ''))

    @staticmethod
    def _meta_menu_entries(menu):
        """Same conversion of provider menus to Kodi actions as xbmcutil.add_video."""
        entries = []
        for title, action in menu.items():
            if not isinstance(action, dict):
                entries.append((title, action))
                continue
            action = dict(action)
            kind = action.pop('action-type', None)
            url = xbmcutil._create_plugin_url(action)
            if kind == 'list':
                entries.append((title, 'Container.Update(%s)' % url))
            elif kind == 'play':
                entries.append((title, 'PlayMedia(%s)' % url))
            else:
                entries.append((title, 'RunPlugin(%s)' % url))
        return entries

    def _meta_plot(self, info, plot=None):
        plot = to_text(info.get('plot') if plot is None else plot).strip()
        line = ratings_line(info) if self._meta_ratings_in_plot() else ''
        if line and plot:
            return line + '[CR][CR]' + plot
        return line or plot

    def _meta_ratings_in_plot(self):
        return self.meta_bool('meta-ratings-in-plot', True) and not self.meta_items_only()

    def _meta_has_addon(self, addon_id):
        if self._meta_addons is None:
            self._meta_addons = {}
        if addon_id not in self._meta_addons:
            try:
                self._meta_addons[addon_id] = bool(
                    xbmc.getCondVisibility('System.HasAddon(%s)' % addon_id))
            except Exception:
                self._meta_addons[addon_id] = False
        return self._meta_addons[addon_id]

    def meta_youtube_url(self, video_id):
        """
        A YouTube trailer as a Kodi playable path, or '' when no installed
        add-on can play it. SendToKodi (yt-dlp) is used by default, the
        YouTube add-on when it is chosen in the settings or SendToKodi is missing.
        """
        if not video_id:
            return ''
        preferred = self.meta_enum('meta-trailer-player', ['sendtokodi', 'youtube'])
        order = [preferred] + [n for n in ('sendtokodi', 'youtube') if n != preferred]
        if sys.version_info < SENDTOKODI_MIN_PYTHON and 'youtube' in order:
            # SendToKodi's yt-dlp needs Python 3.10+; Kodi's Python is older here, so
            # the YouTube add-on goes first (SendToKodi stays as a last resort)
            order.remove('youtube')
            order.insert(0, 'youtube')
        for name in order:
            addon_id, pattern = TRAILER_PLAYERS[name]
            if not self._meta_has_addon(addon_id):
                continue
            if name == 'sendtokodi':
                return pattern % urllib.parse.quote(YOUTUBE_WATCH % video_id, safe='')
            return pattern % video_id
        return ''

    def _meta_trailer_url(self, ref, info):
        if not info.get('has_trailer') or not self.meta_bool('meta-trailers', True) \
                or self.meta_items_only():
            return ''
        direct = self.meta_youtube_url((info.get('youtube') or [''])[0])
        if direct:
            # already known (TMDb): hand Kodi the player address directly
            return direct
        params = self.params()
        params.update(self._meta_ref_params(ref))
        params['meta'] = 'trailer'
        return xbmcutil._create_plugin_url(params)

    def _meta_title_record(self, item, info):
        ref = self._meta_ref(item)
        record = dict(info)
        record['mediatype'] = item['mediatype']
        record['title'] = to_text(item.get('name') or item.get('title'))
        if record['title'] == to_text(record.get('originaltitle')):
            record['originaltitle'] = ''
        plot = to_text(info.get('plot')).strip()
        if not plot and item['mediatype'] == 'tvshow':
            plot = to_text(item.get('plot')).strip()     # Sosac's own description
        record['plot'] = self._meta_plot(info, plot)
        record['plotoutline'] = _outline(plot)
        if not record.get('ratings') and item.get('rating'):
            # nothing found online: keep the rating Sosac sends with the list
            record['ratings'] = {'sosac': {'rating': float(item['rating']), 'votes': 0}}
            record['default_rating'] = 'sosac'
        record['trailer'] = self._meta_trailer_url(ref, info)
        record['resolution'] = _resolution(item.get('quality'))
        record['audio'] = _audio_languages(item.get('lang'))
        return record

    def _meta_episode_record(self, item, show, extra, season, number):
        name = to_text(item.get('name')).strip() or to_text(extra.get('title')).strip() \
            or to_text(item.get('title'))
        plot = to_text(extra.get('plot')).strip()
        record = {
            'mediatype': 'episode',
            'title': name,
            'tvshowtitle': to_text(item.get('show')) or to_text(show.get('title')),
            'season': season,
            'episode': number,
            'year': to_int(str(extra.get('aired') or '')[:4]) or show.get('year'),
            'aired': extra.get('aired') or '',
            'duration': extra.get('duration') or show.get('duration'),
            'genres': show.get('genres'),
            'countries': show.get('countries'),
            'directors': show.get('directors'),
            'writers': show.get('writers'),
            'studios': show.get('studios'),
            'mpaa': show.get('mpaa'),
            'cast': show.get('cast'),
            # these numbers belong to the show, not to the episode
            'ids': dict(('tvshow.' + key, value) for key, value in (show.get('ids') or {}).items()),
            'resolution': _resolution(item.get('quality')),
            'audio': _audio_languages(item.get('lang')),
        }
        if extra.get('rating'):
            record['ratings'] = {'imdb': {'rating': extra['rating'], 'votes': extra.get('votes')}}
            record['default_rating'] = 'imdb'
            line = ratings_line(record) if self._meta_ratings_in_plot() else ''
            record['plot'] = (line + '[CR][CR]' + plot) if line and plot else (plot or line)
        else:
            record['plot'] = plot
        if not record['plot']:
            # no text for the episode itself: the show's plot beats an empty panel
            record['plot'] = self._meta_plot(show)
        record['plotoutline'] = _outline(plot or to_text(show.get('plot')))
        return record

    @staticmethod
    def _meta_art(info, image, still=None, kind='movie'):
        """
        image: the picture Sosac sends with the item. Sosac's pictures are tiny
               (75x109 px movie posters), so they are never used as poster or
               fanart; only as the list icon when nothing was found online.
        still: None for movies and shows; for episodes the episode picture
               found online ('' when there is none).
        """
        fanart = to_text(info.get('fanart'))
        art = {}
        if info.get('landscape'):
            art['landscape'] = info['landscape']
        if still is None:
            poster = to_text(info.get('poster'))
            thumb = poster or image
            if kind == 'tvshow' and image and not fanart and not info.get('landscape'):
                # a TV show's Sosac picture is a 558x313 still: usable as a wide picture
                art['landscape'] = image
        else:
            poster = to_text(info.get('poster'))
            thumb = still or image or poster
            if poster:
                art['tvshow.poster'] = poster
            if info.get('clearlogo'):
                art['tvshow.clearlogo'] = info['clearlogo']
            if fanart:
                art['tvshow.fanart'] = fanart
            else:
                fanart = still or image
        if thumb:
            art['thumb'] = thumb
            art['icon'] = thumb
        if poster:
            art['poster'] = poster
        if fanart:
            art['fanart'] = fanart
            art.setdefault('landscape', fanart)
        if info.get('clearlogo'):
            art['clearlogo'] = info['clearlogo']
        return art

    # -- playback ---------------------------------------------------------

    def _meta_playing(self, item):
        """Builds the record + art for the item being played, from the cache only."""
        stored = self.meta_engine().cache.get('play:' + to_text(item['url']))
        if not stored:
            return None
        engine = self.meta_engine()
        ref = stored['ref']
        info = engine.peek(ref) if engine.can_lookup(ref) else engine.merge(ref, {})
        if stored['kind'] == 'episode':
            extra = {}
            if engine.can_lookup(ref):
                extra = engine.episodes(ref, stored['season'], network=False)[0].get(
                    str(stored['episode'])) or {}
            fake = {'mediatype': 'episode', 'name': stored.get('name'), 'show': ref.get('title'),
                    'title': to_text(item['info'].get('title'))}
            record = self._meta_episode_record(fake, info, extra, stored['season'],
                                               stored['episode'])
            art = self._meta_art(info, stored.get('img') or '',
                                 imdb_source.image(extra.get('thumb'), width=1280) or '')
        else:
            fake = {'mediatype': 'movie', 'name': ref.get('title'), 'title': ref.get('title'),
                    'imdb': ref.get('imdb'), 'csfd': ref.get('csfd'), 'year': ref.get('year'),
                    'names': ref.get('names'), 'genres': ref.get('genres')}
            record = self._meta_title_record(fake, info)
            art = self._meta_art(info, stored.get('img') or '')
        record.pop('trailer', None)
        record.pop('resolution', None)     # Kodi reads the real stream details itself
        record.pop('audio', None)
        return record, art

    def play(self, item):
        playing = None
        if self.meta_on():
            try:
                playing = self._meta_playing(item)
            except Exception:
                log('no metadata for the playing item: %s' % traceback.format_exc())
        key = 'v:' + to_text(item['url'])
        start = 0
        if self.meta_history() is not None:
            start = self._meta_resume(key)
            if start is None:           # "back" in the resume question
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
                return

        # from here on this mirrors XBMContentProvider.play()
        stream = self.resolve(item['url'])
        if stream:
            xbmcutil.reportUsage(self.addon_id, self.addon_id + '/play')
            url = stream['url']
            if isinstance(url, bytes):
                url = url.decode('utf-8')
            if 'headers' in stream.keys():
                headers = '|' + urllib.parse.urlencode(stream['headers'])
                if len(headers) > 1:
                    url = url + headers
            li = xbmcgui.ListItem(path=url)
            try:
                if playing:
                    playing = self.meta_sized(*playing)
                    if self.meta_pictures() is not None:
                        playing = (playing[0], self.meta_pictures().localize(playing[1]))
                    apply_info(li, playing[0])
                    li.setArt(dict({'icon': 'DefaultVideo.png'}, **playing[1]))
                else:
                    labels = self._extract_infolabels(item['info'])
                    if labels:
                        li.setInfo('video', labels)
                    li.setArt({'icon': 'DefaultVideo.png'})
            except Exception:
                log('could not attach metadata: %s' % traceback.format_exc())
            if start:
                li.setProperty('StartOffset', '%.1f' % start)
            if self.meta_history() is not None:
                try:
                    watchtracker.announce(key, self._meta_history_data(item))
                except Exception:
                    log('history note: %s' % traceback.format_exc())
            try:
                xbmcutil.set_subtitles(li, stream['subs'], stream.get('headers'))
            except Exception:
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
                xbmcutil.load_subtitles(stream['subs'], stream.get('headers'))
            else:
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)

    # -- trailers ---------------------------------------------------------

    def _meta_trailer(self, params):
        handle = int(sys.argv[1])
        ref = self._meta_ref_from_params(params)
        ref['csfd'] = None      # the trailer comes from TMDb or IMDb
        found = {'youtube': [], 'url': ''}
        players = any(self._meta_has_addon(TRAILER_PLAYERS[n][0]) for n in TRAILER_PLAYERS)
        try:
            found = self.meta_engine().trailer(ref, direct=not players)
        except Exception:
            log('trailer lookup failed: %s' % traceback.format_exc())
        url = self.meta_youtube_url((found['youtube'] or [''])[0]) or found['url']
        log('trailer for %s: youtube=%s direct=%s -> %s' % (
            ref.get('title'), found['youtube'], bool(found['url']), url or 'nothing'))
        if not url and self.meta_engine().tmdb_problem:
            self._meta_report_tmdb(self.meta_engine())
        if not url:
            self.meta_notify(self.meta_string(S_NEED_YOUTUBE if found['youtube']
                                              else S_NO_TRAILER))
            if handle >= 0:
                xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        title = '%s %s' % (ref.get('title') or '', self.meta_string(S_TRAILER_SUFFIX))
        li = xbmcgui.ListItem(title.strip(), path=url)
        apply_info(li, {'mediatype': 'video', 'title': title.strip()})
        if handle >= 0:
            xbmcplugin.setResolvedUrl(handle, True, li)
        else:
            xbmc.Player().play(url, li)
