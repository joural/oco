# -*- coding: UTF-8 -*-
"""
The metadata engine: asks the sources, merges what they return into one
record in the wanted language and keeps everything in the cache.

Source records and translations are cached, the merged result is not: it is
rebuilt on every call, so changing a setting (language, preferred source,
default rating...) takes effect immediately without refetching anything.
"""

import hashlib
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from concurrent.futures import TimeoutError as FutureTimeout

from . import csfd, imdb, net, tmdb
from .cache import Cache
from .textutil import detect_cs_sk, localize_genres, to_int, to_text
from .translate import Translator

DAY = 86400

DEFAULTS = {
    'client': '',              # how to introduce the add-on to CSFD (see net.CLIENT)
    'lang': 'sk',              # sk | cs | en
    'plot_source': 'auto',     # auto | csfd | imdb
    'use_csfd': True,
    'use_imdb': True,
    'tmdb_key': '',
    'tmdb_search': True,       # find titles without an IMDb number on TMDb by name + year
    'translate': True,
    'translator': 'google',    # google | deepl | mymemory
    'deepl_key': '',
    'accept_related': False,   # show Czech text as it is when Slovak is wanted (and vice versa)
    'default_rating': 'auto',  # auto | csfd | imdb
    'cache_days': 30,
    'workers': 4,
    'budget': 25,              # seconds one listing may spend on the network
}

RELATED = {('cs', 'sk'), ('sk', 'cs')}


def make_ref(imdb_id=None, csfd_id=None, mediatype='movie', title='', year=0, genres=None,
             names=None, plot=''):
    """
    What is known about a title from Sosac itself.

    names: every name Sosac sends for it ({'cs': ..., 'en': ...} or a list);
           used to find it on TMDb when there is no IMDb number
    plot:  Sosac's own description (TV shows have one)
    """
    if isinstance(names, dict):
        # English first: that is what TMDb searches best
        names = [names.get('en')] + [v for k, v in sorted(names.items()) if k != 'en']
    search = []
    for name in list(names or []) + [title]:
        name = to_text(name).strip()
        if name and name not in search:
            search.append(name)
    return {
        'imdb': imdb.normalize_id(imdb_id),
        'csfd': csfd.normalize_id(csfd_id),
        'mediatype': mediatype or 'movie',
        'title': to_text(title),
        'year': to_int(year),
        'genres': list(genres or []),
        'names': search,
        'plot': to_text(plot).strip(),
    }


def ref_key(ref):
    if has_ids(ref):
        return '%s|%s' % (ref.get('imdb') or '-', ref.get('csfd') or '-')
    # no numbers: the Sosac title and year are all there is
    return 'q|%s|%s|%s' % (ref.get('mediatype') or 'movie', to_int(ref.get('year')),
                           (ref.get('names') or [ref.get('title') or ''])[0].lower())


def has_ids(ref):
    return bool(ref and (ref.get('imdb') or ref.get('csfd')))


class Engine(object):

    def __init__(self, config=None, cache=None, log=None):
        self.cfg = dict(DEFAULTS)
        self.cfg.update(config or {})
        if self.cfg['lang'] not in ('sk', 'cs', 'en'):
            self.cfg['lang'] = 'en'
        self.log = log or (lambda msg: None)
        self.cache = cache if cache is not None else Cache(None, self.log)
        self.ttl = max(1, to_int(self.cfg['cache_days'], 30)) * DAY
        self.translator = Translator(self.cfg['translator'], self.cfg['deepl_key'], self.cache)
        self.cfg['tmdb_key'] = tmdb.clean_key(self.cfg['tmdb_key'])
        self.tmdb_key_problem = tmdb.key_problem(self.cfg['tmdb_key']) if self.cfg['tmdb_key'] else ''
        # a value that cannot be a TMDb key is not sent at all (it would only get HTTP 401)
        self.tmdb = tmdb.TMDb(self.cfg['tmdb_key']) \
            if self.cfg['tmdb_key'] and not self.tmdb_key_problem else None
        # lookups are cached per API key, so correcting a mistyped key works at once
        self._tmdb_ns = 's:tmdbid:%s:' % hashlib.sha1(
            str(self.cfg['tmdb_key']).encode('utf-8')).hexdigest()[:6]
        # what happened to TMDb during this run: '' (fine / not asked), 'nokey',
        # 'rejected' (HTTP 401), 'down' (unreachable) or 'error'
        self.tmdb_problem = '' if self.tmdb else ('badkey' if self.tmdb_key_problem else 'nokey')
        self.tmdb_error = self.tmdb_key_problem
        self.tmdb_calls = 0
        if self.tmdb and self.cache.get(self._tmdb_ns + 'rejected', max_age=3600):
            # the same key was refused less than an hour ago: do not hammer TMDb with it
            self.tmdb = None
            self.tmdb_problem = 'rejected'
        self._cancel = threading.Event()
        self._locks = {}
        self._locks_guard = threading.Lock()
        self.blocked = []          # hosts that turned us away during this run
        if self.cfg.get('client'):
            net.CLIENT = str(self.cfg['client'])
        net.restore_paused(self.cache.get('net:paused'))

    # -- cached access to one source record ------------------------------

    def _lookup(self, key, ttl):
        """Cache only. Returns (record, usable, stale record)."""
        entry = self.cache.get_entry(key)
        if not entry:
            return None, False, None
        age = time.time() - entry[0]
        value = entry[1]
        if isinstance(value, dict) and '_err' in value:
            if value['_err'] != 404 and self._is_tmdb_key(key):
                return None, False, None     # a TMDb failure is always tried again
            return None, age < (7 * DAY if value['_err'] == 404 else 3600), None
        if age < ttl:
            return value, True, None
        return None, False, value

    def _source(self, key, fetcher, network, ttl=None):
        """Returns (record or None, resolved). resolved=False: needs network."""
        ttl = ttl or self.ttl
        value, usable, stale = self._lookup(key, ttl)
        if usable:
            return value, True
        if not network or self._cancel.is_set():
            return stale, False
        # two list entries can point at the same film: fetch it once
        with self._locks_guard:
            lock = self._locks.setdefault(key, threading.Lock())
        with lock:
            return self._fetch_source(key, fetcher, ttl, stale)

    def _is_tmdb_key(self, key):
        return key.startswith(self._tmdb_ns) or key.startswith('s:tmdb:') or \
            key.startswith('e:tmdb:')

    def _fetch_source(self, key, fetcher, ttl, stale):
        value, usable, _ = self._lookup(key, ttl)
        if usable:                      # another worker got it while we waited
            return value, True
        is_tmdb = self._is_tmdb_key(key)
        if is_tmdb:
            if not self.tmdb:           # the key was refused by another worker meanwhile
                return stale, True
            self.tmdb_calls += 1
        try:
            value = fetcher()
        except tmdb.KeyRejected as e:
            self.log('%s: %s' % (key, e))
            self.tmdb_problem, self.tmdb_error = 'rejected', str(e)
            self.tmdb = None
            self.cache.set(self._tmdb_ns + 'rejected', True)
            return stale, True
        except net.HostDown as e:
            if is_tmdb:
                if self.tmdb_problem != 'down':
                    self.log('TMDb skipped: %s' % e)
                self.tmdb_problem, self.tmdb_error = 'down', str(e)
            return stale, True
        except net.Blocked as e:
            # the site said no: remember that (also for the next runs) and move on
            host = net._host(e.url)
            if host and net.pause(host, e.pause):
                self.log('%s: %s; not asking %s again for %d minutes'
                         % (key, e, host, e.pause // 60))
                self.blocked.append(host)
                self.cache.set('net:paused', net.paused_hosts())
            return stale, True
        except net.FetchError as e:
            self.log('%s: %s' % (key, e))
            if is_tmdb and e.code != 404:
                self.tmdb_problem, self.tmdb_error = 'error', str(e)[:300]
            if stale is None and not (is_tmdb and e.code != 404):
                self.cache.set(key, {'_err': e.code, 'msg': str(e)[:200]})
            return stale, True
        except Exception:
            # a parser tripping over an unexpected page must never break a listing
            self.log('%s: %s' % (key, traceback.format_exc()))
            if is_tmdb:
                self.tmdb_problem, self.tmdb_error = 'error', 'internal error, see kodi.log'
            if stale is None and not is_tmdb:
                self.cache.set(key, {'_err': 0, 'msg': 'internal error'})
            return stale, True
        self.cache.set(key, value)
        return value, True

    def _tmdb_find(self, ref):
        found = self.tmdb.find(ref['imdb'], ref.get('mediatype'))
        if not found:
            raise net.FetchError('TMDb does not know %s' % ref['imdb'], code=404)
        return {'kind': found[0], 'id': found[1]}

    def _tmdb_search(self, ref):
        found = self.tmdb.search(ref.get('names'), ref.get('year'), ref.get('mediatype'),
                                 self.cfg['lang'])
        if not found:
            raise net.FetchError('TMDb found nothing for %s (%s)'
                                 % (' / '.join(ref.get('names') or []), ref.get('year')), code=404)
        return {'kind': found[0], 'id': found[1], 'searched': True}

    def _searchable(self, ref):
        return bool(self.tmdb and self.cfg['tmdb_search'] and ref and ref.get('names'))

    def _search_key(self, ref):
        names = '|'.join(ref.get('names') or []).lower()
        return '%sq:%s:%s:%s' % (self._tmdb_ns, ref.get('mediatype') or 'movie',
                                 to_int(ref.get('year')),
                                 hashlib.sha1(names.encode('utf-8')).hexdigest()[:12])

    def can_lookup(self, ref):
        """True when any source can say something about this title."""
        return has_ids(ref) or self._searchable(ref)

    def tmdb_id(self, ref, network=True):
        """
        Returns ({'kind': 'movie'|'tv', 'id': ...} or None, resolved).
        By the IMDb number when Sosac sends one, otherwise (or when TMDb does
        not know that number) by searching for the Sosac title and year.
        """
        if not self.tmdb:
            return None, True
        complete = True
        if ref.get('imdb'):
            found, ok = self._source(self._tmdb_ns + ref['imdb'],
                                     lambda: self._tmdb_find(ref), network)
            if found or not ok:
                return found, ok
        if self._searchable(ref):
            found, ok = self._source(self._search_key(ref), lambda: self._tmdb_search(ref), network)
            return found, complete and ok
        return None, complete

    def _records(self, ref, network):
        lang = self.cfg['lang']
        recs, complete = {}, True
        if self.tmdb:
            found, ok = self.tmdb_id(ref, network)
            complete &= ok
            if found and self.tmdb:
                recs['tmdb'], ok = self._source(
                    's:tmdb:%s:%s:%s' % (found['kind'], found['id'], lang),
                    lambda: self.tmdb.title(found['kind'], found['id'], lang), network)
                complete &= ok
        if self.cfg['use_imdb'] and ref.get('imdb'):
            tt = ref['imdb']
            recs['imdb'], ok = self._source('s:imdb:' + tt, lambda: imdb.fetch_title(tt), network)
            complete &= ok
        if self.cfg['use_csfd'] and ref.get('csfd'):
            cid = ref['csfd']
            site = 'sk' if lang == 'sk' else 'cs'
            rec, ok = self._source('s:csfd:%s:%s' % (site, cid),
                                   lambda: csfd.fetch_title(cid, site), network)
            if rec is None and ok and site == 'sk':
                # csfd.sk did not answer: the Czech site has the same film ids
                rec, ok = self._source('s:csfd:cs:%s' % cid,
                                       lambda: csfd.fetch_title(cid, 'cs'), network)
            recs['csfd'] = rec
            complete &= ok
        return recs, complete

    # -- merging ---------------------------------------------------------

    def _closeness(self, text_lang):
        lang = self.cfg['lang']
        if text_lang == lang:
            return 0
        return 1 if (text_lang, lang) in RELATED else 2

    def _pick_plot(self, recs, ref=None):
        lang = self.cfg['lang']
        preference = self.cfg['plot_source']
        explicit = preference in ('csfd', 'imdb', 'tmdb')
        if not explicit:
            if self.tmdb:
                preference = 'tmdb'
            else:
                preference = 'csfd' if lang in ('sk', 'cs') else 'imdb'
        order = {'csfd': ['csfd', 'tmdb', 'imdb'], 'imdb': ['imdb', 'tmdb', 'csfd'],
                 'tmdb': ['tmdb', 'csfd', 'imdb']}[preference]
        # Sosac's own description (TV shows) always comes first
        order = ['sosac'] + order
        candidates = []
        sosac_plot = (ref or {}).get('plot')
        if sosac_plot:
            candidates.append((sosac_plot, detect_cs_sk(sosac_plot) or 'cs', 'sosac'))
        rec = recs.get('csfd') or {}
        if rec.get('plot'):
            candidates.append((rec['plot'], rec.get('plot_lang') or 'cs', 'csfd'))
        rec = recs.get('imdb') or {}
        if rec.get('plot'):
            candidates.append((rec['plot'], 'en', 'imdb'))
        for code, text in ((recs.get('tmdb') or {}).get('plots') or {}).items():
            if text:
                candidates.append((text, code, 'tmdb'))
        if not candidates:
            return None
        if explicit or sosac_plot:
            # the user named a source (or Sosac has its own text): take it, translate if needed
            candidates.sort(key=lambda c: (order.index(c[2]), self._closeness(c[1])))
        else:
            # otherwise text that is already in the right language wins
            candidates.sort(key=lambda c: (self._closeness(c[1]), order.index(c[2])))
        return candidates[0]

    def merge(self, ref, recs):
        lang = self.cfg['lang']
        local = lang in ('sk', 'cs')
        im = recs.get('imdb') or {}
        cs = recs.get('csfd') or {}
        tm = recs.get('tmdb') or {}

        def first(*values):
            for value in values:
                if value:
                    return value
            return values[-1] if values else None

        info = {
            'mediatype': ref.get('mediatype') or 'movie',
            'ids': {},
            'sources': [name for name in ('csfd', 'imdb', 'tmdb') if recs.get(name)],
            'lang': lang,
        }
        if ref.get('imdb') or tm.get('imdb'):
            info['ids']['imdb'] = ref.get('imdb') or imdb.normalize_id(tm.get('imdb'))
        if ref.get('csfd'):
            info['ids']['csfd'] = ref['csfd']
        if tm.get('id'):
            info['ids']['tmdb'] = tm['id']

        # Sosac's own data (title, year, genres, description) comes first;
        # TMDb fills in what Sosac does not send, ČSFD / IMDb fill remaining gaps
        info['title'] = ref.get('title') or first(cs.get('title') if local else tm.get('title'),
                                                  tm.get('title'), im.get('title'), cs.get('title'), '')
        info['originaltitle'] = first(tm.get('originaltitle'), im.get('originaltitle'),
                                      cs.get('originaltitle'), '')
        info['year'] = first(ref.get('year'), tm.get('year'), im.get('year'), cs.get('year'), 0)

        plot = self._pick_plot(recs, ref)
        info['plot'], info['plot_lang'], info['plot_source'] = plot if plot else ('', lang, '')
        info['plot_translated'] = False

        info['tagline'] = first((tm.get('taglines') or {}).get(lang),
                                im.get('tagline') if lang == 'en' else '', '')
        if local:
            genres = first(ref.get('genres'), tm.get('genres'), cs.get('genres'), im.get('genres'), [])
            countries = first(tm.get('countries'), cs.get('countries'), im.get('countries'), [])
        else:
            genres = first(ref.get('genres'), tm.get('genres'), im.get('genres'), cs.get('genres'), [])
            countries = first(tm.get('countries'), im.get('countries'), cs.get('countries'), [])
        info['genres'] = localize_genres(genres, lang)
        info['countries'] = list(countries)
        info['directors'] = list(first(tm.get('directors'), im.get('directors'),
                                       cs.get('directors'), []))
        info['writers'] = list(first(tm.get('writers'), im.get('writers'), cs.get('writers'), []))
        info['studios'] = list(tm.get('studios') or [])
        info['cast'] = [dict(person, thumb=imdb.image(person.get('thumb'), height=632))
                        for person in first(tm.get('cast'), im.get('cast'), cs.get('cast'), [])]
        info['duration'] = first(tm.get('duration'), im.get('duration'), cs.get('duration'), 0)
        info['mpaa'] = first(tm.get('mpaa'), im.get('mpaa'), '')
        info['premiered'] = first(tm.get('premiered'), im.get('premiered'), '')
        info['status'] = tm.get('status') or ''

        # artwork: never Sosac's (75x109 px); TMDb in high resolution, then ČSFD / IMDb
        im_poster = imdb.image(im.get('poster'), width=1000)
        if local:
            info['poster'] = first(tm.get('poster'), cs.get('poster'), im_poster, '')
        else:
            info['poster'] = first(tm.get('poster'), im_poster, cs.get('poster'), '')
        info['fanart'] = first(tm.get('fanart'), imdb.image(im.get('fanart'), width=1920), '')
        info['landscape'] = tm.get('landscape') or ''
        info['clearlogo'] = tm.get('clearlogo') or ''

        ratings = {}
        for name, rec in (('csfd', cs), ('imdb', im), ('tmdb', tm)):
            if rec.get('rating'):
                ratings[name] = {'rating': round(float(rec['rating']), 1),
                                 'votes': to_int(rec.get('votes'))}
        info['ratings'] = ratings
        default = self.cfg['default_rating']
        if default not in ('csfd', 'imdb'):
            default = 'csfd' if local else 'imdb'
        if default not in ratings:
            available = [n for n in ('imdb', 'csfd', 'tmdb') if n in ratings]
            default = available[0] if available else ''
        info['default_rating'] = default

        info['youtube'] = list(tm.get('youtube') or [])
        # a record from the reduced IMDb query does not say whether a video exists;
        # assume it does and find out when the trailer is actually requested
        info['has_trailer'] = bool(info['youtube']) or \
            (bool(ref.get('imdb')) and bool(im.get('has_video', True)))
        return info

    def _translate_field(self, holder, network, field='plot', lang_field='plot_lang'):
        """Translates holder[field] in place. Returns False when network is still needed."""
        lang = self.cfg['lang']
        text, src = holder.get(field), holder.get(lang_field)
        if not text or not src or src == lang or not self.cfg['translate']:
            return True
        if self.cfg['accept_related'] and (src, lang) in RELATED:
            return True
        hit = self.translator.cached(text, src, lang)
        if not hit:
            if not network or self._cancel.is_set():
                return False
            try:
                hit = self.translator.translate(text, src, lang)
            except net.HostDown:
                return True
            except net.FetchError as e:
                self.log('translate %s->%s: %s' % (src, lang, e))
                return True
            except Exception:
                self.log('translate: %s' % traceback.format_exc())
                return True
        holder[field + '_original'] = text
        holder[field] = hit
        holder[lang_field] = lang
        holder[field + '_translated'] = True
        return True

    # -- public API ------------------------------------------------------

    def resolve(self, ref, network=True):
        """Returns (info, complete). complete=False means more could be fetched."""
        recs, complete = self._records(ref, network)
        info = self.merge(ref, recs)
        complete &= self._translate_field(info, network)
        return info, complete

    def peek(self, ref):
        """Whatever the cache already knows; never touches the network."""
        return self.resolve(ref, network=False)[0]

    def episodes(self, ref, season, network=True):
        """Returns ({'1': {...}, '2': {...}}, complete) for one season of a show."""
        lang = self.cfg['lang']
        season = str(to_int(season))
        ttl = min(self.ttl, 7 * DAY)
        complete, found = True, None
        if not ref.get('imdb') and not self._searchable(ref):
            return {}, True
        if self.tmdb:
            tid, ok = self.tmdb_id(ref, network)
            complete &= ok
            if tid and tid['kind'] == 'tv':
                found, ok = self._source('e:tmdb:%s:%s:%s' % (tid['id'], season, lang),
                                         lambda: self.tmdb.season(tid['id'], season, lang),
                                         network, ttl)
                complete &= ok
        if not found and self.cfg['use_imdb'] and ref.get('imdb'):
            tt = ref['imdb']
            found, ok = self._source('e:imdb:%s:%s' % (tt, season),
                                     lambda: imdb.fetch_episodes(tt, season), network, ttl)
            complete &= ok
        episodes = {}
        for number, episode in (found or {}).items():
            episode = dict(episode)
            complete &= self._translate_field(episode, network)
            episodes[number] = episode
        return episodes, complete

    def get_many(self, refs, seasons=(), progress=None):
        """
        Resolves many titles (and seasons) at once.

        refs:     list of refs
        seasons:  list of (ref, season)
        progress: callable(done, total); return False to stop early
        Returns (titles, episodes): {ref_key: info}, {(ref_key, season): {...}}
        """
        self._cancel.clear()
        net.CANCEL.clear()
        titles, shows, jobs = {}, {}, []
        keys = []
        for ref in refs:
            if ref.get('imdb'):
                keys += ['s:imdb:' + ref['imdb'], self._tmdb_ns + ref['imdb']]
            if ref.get('csfd'):
                keys += ['s:csfd:sk:' + ref['csfd'], 's:csfd:cs:' + ref['csfd']]
            if self._searchable(ref):
                keys.append(self._search_key(ref))
        self.cache.preload(keys)

        for ref in refs:
            key = ref_key(ref)
            if key in titles or not self.can_lookup(ref):
                continue
            titles[key], complete = self.resolve(ref, network=False)
            if not complete:
                jobs.append(('title', key, ref, None))
        for ref, season in seasons:
            key = (ref_key(ref), str(to_int(season)))
            if key in shows or not (ref.get('imdb') or self._searchable(ref)):
                continue
            shows[key], complete = self.episodes(ref, season, network=False)
            if not complete:
                jobs.append(('season', key, ref, season))

        budget = to_int(self.cfg['budget'], 25)
        if not jobs or budget <= 0:
            return titles, shows

        def work(job):
            kind, key, ref, season = job
            if kind == 'title':
                return job, self.resolve(ref)[0]
            return job, self.episodes(ref, season)[0]

        done, total = 0, len(jobs)
        if progress:
            progress(0, total)
        workers = max(1, min(8, to_int(self.cfg['workers'], 4)))
        pool = ThreadPoolExecutor(max_workers=workers)
        try:
            futures = [pool.submit(work, job) for job in jobs]
            try:
                for future in as_completed(futures, timeout=budget):
                    try:
                        job, value = future.result()
                    except Exception:
                        self.log('worker: %s' % traceback.format_exc())
                        continue
                    if job[0] == 'title':
                        titles[job[1]] = value
                    else:
                        shows[job[1]] = value
                    done += 1
                    if progress and progress(done, total) is False:
                        self._cancel.set()
                        break
            except FutureTimeout:
                self.log('time budget of %ds used up, %d of %d items done; '
                         'the rest is fetched next time' % (budget, done, total))
                self._cancel.set()
        finally:
            # queued jobs see the cancel flag and return at once; requests that are
            # already on the wire finish (at most one timeout) and are cached
            self._cancel.set()
            net.CANCEL.set()
            pool.shutdown(wait=True)
            self._cancel.clear()
            net.CANCEL.clear()
            self.cache.set('net:paused', net.paused_hosts())
        return titles, shows

    def trailer(self, ref, direct=False):
        """
        Returns {'youtube': [ids], 'url': direct url or ''} (fetched now).
        direct=True: also look for a direct video (IMDb) when YouTube ids were
        found, for systems without an add-on that can play YouTube.
        """
        out = {'youtube': [], 'url': ''}
        if self.tmdb and (ref.get('imdb') or self._searchable(ref)):
            found, _ = self.tmdb_id(ref, True)
            if found:
                rec, _ = self._source(
                    's:tmdb:%s:%s:%s' % (found['kind'], found['id'], self.cfg['lang']),
                    lambda: self.tmdb.title(found['kind'], found['id'], self.cfg['lang']), True)
                out['youtube'] = list((rec or {}).get('youtube') or [])
        if (out['youtube'] and not direct) or not ref.get('imdb'):
            return out
        tt = ref['imdb']
        # IMDb video links are signed and expire, so they are kept only briefly
        video, _ = self._source('v:imdb:' + tt, lambda: imdb.fetch_trailer(tt) or {}, True, 3600)
        out['url'] = (video or {}).get('url') or ''
        return out

    def forget(self, ref):
        keys = []
        if self._searchable(ref):
            found = self.cache.get(self._search_key(ref)) or {}
            keys.append(self._search_key(ref))
            if found.get('id'):
                self.cache.delete_prefix('s:tmdb:%s:%s:' % (found['kind'], found['id']))
                self.cache.delete_prefix('e:tmdb:%s:' % found['id'])
        if ref.get('imdb'):
            tt = ref['imdb']
            found = self.cache.get(self._tmdb_ns + tt) or {}
            keys += ['s:imdb:' + tt, self._tmdb_ns + tt, 'v:imdb:' + tt]
            self.cache.delete_prefix('e:imdb:%s:' % tt)
            if found.get('id'):
                self.cache.delete_prefix('s:tmdb:%s:%s:' % (found['kind'], found['id']))
                self.cache.delete_prefix('e:tmdb:%s:' % found['id'])
        if ref.get('csfd'):
            keys += ['s:csfd:sk:' + ref['csfd'], 's:csfd:cs:' + ref['csfd']]
        self.cache.delete(keys)

    def describe(self):
        """One log line saying which sources are in use and why not."""
        key = str(self.cfg['tmdb_key'] or '')
        if not key:
            tm = 'OFF (no API key in the settings)'
        elif self.tmdb_problem == 'badkey':
            tm = 'OFF (key ...%s: %s)' % (key[-4:], self.tmdb_key_problem)
        elif self.tmdb_problem == 'rejected':
            tm = 'OFF (key ...%s was rejected by TMDb)' % key[-4:]
        else:
            tm = 'on (key ...%s, %d characters, %s)' % (key[-4:], len(key),
                                                     'v4 token' if len(key) > 40 else 'v3 key')
            if self.tmdb_problem:
                tm += ', problem: %s %s' % (self.tmdb_problem, self.tmdb_error)
        paused = ', '.join('%s for %d min' % (h, (t - time.time()) // 60)
                           for h, t in sorted(net.paused_hosts().items())) or 'none'
        return ('sources: TMDb %s; title search %s; ČSFD %s; IMDb %s; language %s; '
                'skipped hosts: %s' % (tm, 'on' if self.cfg['tmdb_search'] else 'off',
                                       'on' if self.cfg['use_csfd'] else 'off',
                                       'on' if self.cfg['use_imdb'] else 'off',
                                       self.cfg['lang'], paused))

    def diagnose(self, imdb_id='tt0111161', csfd_id='2294'):
        """Talks to every configured service once. Returns [(name, ok, detail)]."""
        net.reset()
        lang = self.cfg['lang']
        report = []

        def check(name, call, describe):
            started = time.time()
            try:
                value = call()
                report.append((name, True, '%s (%.1fs)' % (describe(value), time.time() - started)))
                return value
            except Exception as e:
                report.append((name, False, str(e)[:160]))
                return None

        def describe_title(rec):
            return '%s (%s), %s, plot %d chars, %d cast' % (
                rec.get('title'), rec.get('year'), rec.get('rating'),
                len(rec.get('plot') or ''), len(rec.get('cast') or []))

        if self.cfg['use_csfd']:
            site = 'sk' if lang == 'sk' else 'cs'
            check('CSFD (%s)' % csfd.DOMAINS[site], lambda: csfd.fetch_title(csfd_id, site),
                  describe_title)
        if self.cfg['use_imdb']:
            check('IMDb', lambda: imdb.fetch_title(imdb_id), describe_title)
            check('IMDb trailer', lambda: imdb.fetch_trailer(imdb_id),
                  lambda v: 'found' if v else 'no video')
        self.cache.delete(self._tmdb_ns + 'rejected')    # the test asks TMDb again
        key = self.cfg['tmdb_key']
        if not key or self.tmdb_key_problem:
            report.append(('TMDb', False, tmdb.key_problem(key)))
        self.tmdb = self.tmdb or (tmdb.TMDb(key) if key and not self.tmdb_key_problem else None)
        if self.tmdb:
            def tmdb_call():
                kind, tid = self.tmdb.find(imdb_id)
                return self.tmdb.title(kind, tid, lang)
            check('TMDb (key ...%s, %d characters)' % (key[-4:], len(key)), tmdb_call, lambda rec: '%s, plots: %s, %d trailers, poster %s' % (
                rec.get('title'), ','.join(sorted(rec.get('plots') or {})) or '-',
                len(rec.get('youtube') or []), 'yes' if rec.get('poster') else 'no'))
            if self.cfg['tmdb_search']:
                check('TMDb search by title', lambda: self.tmdb.search(
                    ['The Shawshank Redemption', u'Vykoupení z věznice Shawshank'], 1994, 'movie', lang),
                    lambda found: 'found %s/%s' % found if found else 'nothing found')
        if self.cfg['translate']:
            src = 'en' if lang != 'en' else 'cs'
            sample = 'Two imprisoned men bond over a number of years.' if src == 'en' \
                else 'Dva vězni se během let spřátelí.'
            tester = Translator(self.cfg['translator'], self.cfg['deepl_key'], None)
            check('Translation (%s, %s->%s)' % (tester.engine, src, lang),
                  lambda: tester.translate(sample, src, lang), lambda v: v)
        return report
