# -*- coding: UTF-8 -*-
"""
Watch history: what was played, how far, and whether it was finished.

Written by the add-on's service (which follows the player) and read by the
plugin (Continue watching, Watch history, watched ticks in lists). Both run
in different processes, so everything lives in one small SQLite file.
Nothing here imports Kodi modules.
"""

import json
import threading
import time

try:
    import sqlite3
except ImportError:  # pragma: no cover
    sqlite3 = None

# finished when this much was seen, or when only the end credits are left
WATCHED_SHARE = 0.92
WATCHED_REST = 150          # seconds
RESUME_FROM = 60            # an item counts as started after one minute


def is_finished(position, total):
    if not total or total <= 0:
        return False
    return position >= total * WATCHED_SHARE or (total - position) <= WATCHED_REST


class History(object):

    def __init__(self, path=None, log=None):
        self._lock = threading.RLock()
        self._log = log or (lambda msg: None)
        self._db = None
        if sqlite3 is None:
            return
        try:
            self._db = sqlite3.connect(path or ':memory:', timeout=10, check_same_thread=False)
            self._db.execute('CREATE TABLE IF NOT EXISTS watch ('
                             'key TEXT PRIMARY KEY, kind TEXT, show TEXT, season INTEGER, '
                             'episode INTEGER, position REAL, total REAL, watched INTEGER, '
                             'updated INTEGER, data TEXT)')
            self._db.execute('CREATE INDEX IF NOT EXISTS watch_updated ON watch (updated)')
            self._db.commit()
        except Exception as e:
            self._log('history: cannot open %s (%s)' % (path, e))
            self._db = None

    @property
    def ok(self):
        return self._db is not None

    @staticmethod
    def _row(row):
        key, kind, show, season, episode, position, total, watched, updated, data = row
        try:
            data = json.loads(data or '{}')
        except ValueError:
            data = {}
        return {'key': key, 'kind': kind, 'show': show or '', 'season': season or 0,
                'episode': episode or 0, 'position': position or 0.0, 'total': total or 0.0,
                'watched': bool(watched), 'updated': updated or 0, 'data': data}

    _COLUMNS = 'key, kind, show, season, episode, position, total, watched, updated, data'

    # -- writing ---------------------------------------------------------

    def record(self, key, data, position, total, finished=None):
        """
        Saves where playback of one item got to. finished=None decides from
        the position; an item seen to the end is marked watched and its
        resume point cleared.
        """
        if not self.ok or not key:
            return None
        position, total = float(position or 0), float(total or 0)
        old = self.get(key)
        explicit = finished is not None
        if not explicit:
            finished = is_finished(position, total)
        if finished:
            position = 0.0
        if explicit:
            watched = bool(finished)        # "Mark as watched / unwatched"
        else:
            # a short look into something already seen keeps it watched
            watched = finished or bool(old and old['watched'] and position < RESUME_FROM)
        data = dict(data or {})
        with self._lock:
            try:
                self._db.execute(
                    'INSERT OR REPLACE INTO watch (%s) VALUES (?,?,?,?,?,?,?,?,?,?)' % self._COLUMNS,
                    (key, data.get('kind') or 'movie', data.get('show_key') or '',
                     int(data.get('season') or 0), int(data.get('episode') or 0),
                     position, total or (old or {}).get('total') or 0.0, 1 if watched else 0,
                     int(time.time()), json.dumps(data, ensure_ascii=False)))
                self._db.commit()
            except Exception as e:
                self._log('history: write failed (%s)' % e)
        return self.get(key)

    def set_watched(self, key, watched, data=None):
        old = self.get(key)
        if old is None and data is None:
            return None
        return self.record(key, data if data is not None else old['data'], 0,
                           (old or {}).get('total') or 0, finished=bool(watched))

    def remove(self, key):
        self._run('DELETE FROM watch WHERE key=?', (key,))

    def remove_show(self, show_key):
        self._run('DELETE FROM watch WHERE show=?', (show_key,))

    def clear(self):
        self._run('DELETE FROM watch', ())

    def _run(self, sql, args):
        if not self.ok:
            return
        with self._lock:
            try:
                self._db.execute(sql, args)
                self._db.commit()
            except Exception as e:
                self._log('history: %s' % e)

    # -- reading ---------------------------------------------------------

    def _select(self, where='', args=(), tail=''):
        if not self.ok:
            return []
        with self._lock:
            try:
                rows = self._db.execute('SELECT %s FROM watch %s %s'
                                        % (self._COLUMNS, where, tail), args).fetchall()
            except Exception as e:
                self._log('history: read failed (%s)' % e)
                return []
        return [self._row(r) for r in rows]

    def get(self, key):
        rows = self._select('WHERE key=?', (key,))
        return rows[0] if rows else None

    def get_many(self, keys):
        keys = [k for k in set(keys) if k]
        out = {}
        for i in range(0, len(keys), 400):
            chunk = keys[i:i + 400]
            for row in self._select('WHERE key IN (%s)' % ','.join('?' * len(chunk)), chunk):
                out[row['key']] = row
        return out

    def recent(self, limit=100):
        return self._select('', (), 'ORDER BY updated DESC LIMIT %d' % int(limit))

    def unfinished(self):
        """Movies and episodes stopped part way (newest first)."""
        return self._select('WHERE watched=0 AND position>=?', (RESUME_FROM,),
                            'ORDER BY updated DESC')

    def shows(self, limit=50):
        """The most recently played episode of every show (newest first)."""
        rows = self._select("WHERE kind='episode' AND show!=''", (), 'ORDER BY updated DESC')
        seen, out = set(), []
        for row in rows:
            if row['show'] in seen:
                continue
            seen.add(row['show'])
            out.append(row)
            if len(out) >= limit:
                break
        return out

    def watched_in_show(self, show_key):
        return dict(((r['season'], r['episode']), r) for r in
                    self._select('WHERE show=?', (show_key,)))

    def close(self):
        with self._lock:
            if self._db is not None:
                try:
                    self._db.close()
                except Exception:
                    pass
                self._db = None


def next_episode(episodes, last_season, last_episode, done=None):
    """
    episodes: provider items with 'season' and 'episode'.
    Returns the first episode after (last_season, last_episode) that is not
    already watched, or None when the show is caught up.
    """
    done = done or {}
    later = sorted((e for e in episodes
                    if (int(e.get('season') or 0), int(e.get('episode') or 0)) >
                    (int(last_season or 0), int(last_episode or 0))),
                   key=lambda e: (int(e.get('season') or 0), int(e.get('episode') or 0)))
    for item in later:
        row = done.get((int(item.get('season') or 0), int(item.get('episode') or 0)))
        if not (row and row['watched']):
            return item
    return None
