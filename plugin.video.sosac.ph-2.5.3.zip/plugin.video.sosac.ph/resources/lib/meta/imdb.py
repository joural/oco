# -*- coding: UTF-8 -*-
"""
IMDb source.

Primary route is IMDb's own GraphQL endpoint (the one imdb.com itself talks
to); when that is refused the title page is read instead and its schema.org
JSON-LD block is used.
"""

import json
import re

from . import net
from .textutil import strip_tags, to_int, iso_duration

GQL_URLS = ('https://api.graphql.imdb.com/', 'https://caching.graphql.imdb.com/')
GQL_HEADERS = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    # ask for the English edition of titles and plots
    'x-imdb-user-country': 'US',
    'x-imdb-user-language': 'en-US',
}

# Two versions of the title query: when IMDb changes its schema a single
# unknown field makes the whole query fail, so the second one only asks for
# fields that have been stable for years.
Q_TITLE_FULL = '''
query Title($id: ID!) {
  title(id: $id) {
    id
    titleType { id }
    titleText { text }
    originalTitleText { text }
    releaseYear { year endYear }
    releaseDate { year month day }
    runtime { seconds }
    certificate { rating }
    ratingsSummary { aggregateRating voteCount }
    genres { genres { text } }
    plot { plotText { plainText } }
    primaryImage { url }
    countriesOfOrigin { countries { text } }
    taglines(first: 1) { edges { node { text } } }
    directors: principalCredits(filter: {categories: ["director"]}) {
      credits { name { nameText { text } } }
    }
    writers: principalCredits(filter: {categories: ["writer"]}) {
      credits { name { nameText { text } } }
    }
    cast: credits(first: 20, filter: {categories: ["actor", "actress"]}) {
      edges { node {
        name { nameText { text } primaryImage { url } }
        ... on Cast { characters { name } }
      } }
    }
    primaryVideos(first: 1) { edges { node { id thumbnail { url } } } }
  }
}
'''

Q_TITLE_SAFE = '''
query Title($id: ID!) {
  title(id: $id) {
    id
    titleText { text }
    originalTitleText { text }
    releaseYear { year }
    runtime { seconds }
    ratingsSummary { aggregateRating voteCount }
    genres { genres { text } }
    plot { plotText { plainText } }
    primaryImage { url }
  }
}
'''

Q_EPISODES = '''
query Episodes($id: ID!, $season: String!) {
  title(id: $id) {
    episodes {
      episodes(first: 250, filter: {includeSeasons: [$season]}) {
        edges { node {
          id
          titleText { text }
          plot { plotText { plainText } }
          primaryImage { url }
          releaseDate { year month day }
          runtime { seconds }
          ratingsSummary { aggregateRating voteCount }
          series { displayableEpisodeNumber {
            displayableSeason { text } episodeNumber { text }
          } }
        } }
      }
    }
  }
}
'''

Q_TRAILER_FULL = '''
query Trailer($id: ID!) {
  title(id: $id) {
    primaryVideos(first: 3) { edges { node {
      id
      contentType { id }
      thumbnail { url }
      playbackURLs { displayName { value } videoMimeType videoDefinition url }
    } } }
  }
}
'''

Q_TRAILER_SAFE = '''
query Trailer($id: ID!) {
  title(id: $id) {
    primaryVideos(first: 1) { edges { node { id playbackURLs { videoMimeType url } } } }
  }
}
'''


def normalize_id(raw):
    """'0111161', 111161, 'tt0111161' or an imdb URL -> 'tt0111161' (or None)."""
    if raw is None:
        return None
    m = re.search(r'(\d{1,10})', str(raw))
    if not m:
        return None
    number = int(m.group(1))
    if number <= 0:
        return None
    return 'tt%07d' % number


def image(url, width=0, height=0):
    """Asks Amazon's image server for a sensibly sized version."""
    if not url:
        return ''
    if not (width or height) or 'media-amazon.com' not in url:
        return url
    size = 'UX%d' % width if width else 'UY%d' % height
    resized, count = re.subn(r'\._V1_[^/]*?\.(jpe?g|png|webp)$', r'._V1_%s_.\1' % size, url)
    if count:
        return resized
    return re.sub(r'\.(jpe?g|png|webp)$', r'._V1_%s_.\1' % size, url)


def _path(data, *keys):
    for key in keys:
        if isinstance(data, dict):
            data = data.get(key)
        elif isinstance(data, list) and isinstance(key, int) and len(data) > key:
            data = data[key]
        else:
            return None
        if data is None:
            return None
    return data


def _date(node):
    year, month, day = _path(node, 'year'), _path(node, 'month'), _path(node, 'day')
    if year and month and day:
        return '%04d-%02d-%02d' % (int(year), int(month), int(day))
    return ''


def graphql(query, variables, fetch_json=net.fetch_json):
    """Runs a query; raises net.FetchError (code 400 = the query was rejected)."""
    last = None
    for url in GQL_URLS:
        try:
            reply = fetch_json(url, data={'query': query, 'variables': variables},
                               headers=GQL_HEADERS)
        except net.FetchError as e:
            last = e
            if e.code == 400:   # schema problem, the other host will say the same
                break
            continue
        if not isinstance(reply, dict):
            last = net.FetchError('Unexpected IMDb reply', code=0, url=url)
            continue
        if reply.get('data') and _path(reply, 'data', 'title') is not None:
            return reply['data']
        errors = reply.get('errors')
        if errors:
            message = '; '.join(str(_path(e, 'message')) for e in errors[:3])
            rejected = any('validat' in str(_path(e, 'extensions', 'code') or '').lower() or
                           'Cannot query field' in str(_path(e, 'message') or '') or
                           'Unknown argument' in str(_path(e, 'message') or '')
                           for e in errors)
            raise net.FetchError('IMDb query error: %s' % message,
                                 code=400 if rejected else 0, url=url)
        # data.title == null: the id does not exist
        raise net.FetchError('IMDb does not know this id', code=404, url=url)
    raise last or net.FetchError('IMDb not reachable', code=0)


# --- titles ------------------------------------------------------------------

def parse_title(data):
    t = _path(data, 'title') or {}
    record = {'source': 'imdb', 'id': t.get('id') or ''}
    record['title'] = _path(t, 'titleText', 'text') or ''
    record['originaltitle'] = _path(t, 'originalTitleText', 'text') or record['title']
    record['kind'] = _path(t, 'titleType', 'id') or ''
    record['year'] = to_int(_path(t, 'releaseYear', 'year'))
    record['premiered'] = _date(t.get('releaseDate'))
    record['duration'] = to_int(_path(t, 'runtime', 'seconds'))
    record['mpaa'] = _path(t, 'certificate', 'rating') or ''
    record['rating'] = float(_path(t, 'ratingsSummary', 'aggregateRating') or 0)
    record['votes'] = to_int(_path(t, 'ratingsSummary', 'voteCount'))
    record['genres'] = [g.get('text') for g in (_path(t, 'genres', 'genres') or []) if g.get('text')]
    record['plot'] = (_path(t, 'plot', 'plotText', 'plainText') or '').strip()
    record['plot_lang'] = 'en'
    record['tagline'] = _path(t, 'taglines', 'edges', 0, 'node', 'text') or ''
    record['poster'] = _path(t, 'primaryImage', 'url') or ''
    record['countries'] = [c.get('text') for c in (_path(t, 'countriesOfOrigin', 'countries') or [])
                           if c.get('text')]
    for field in ('directors', 'writers'):
        names = []
        for group in t.get(field) or []:
            for credit in group.get('credits') or []:
                name = _path(credit, 'name', 'nameText', 'text')
                if name and name not in names:
                    names.append(name)
        record[field] = names
    cast = []
    for edge in _path(t, 'cast', 'edges') or []:
        node = edge.get('node') or {}
        name = _path(node, 'name', 'nameText', 'text')
        if not name:
            continue
        roles = [c.get('name') for c in node.get('characters') or [] if c.get('name')]
        cast.append({'name': name, 'role': ' / '.join(roles),
                     'thumb': _path(node, 'name', 'primaryImage', 'url') or ''})
    record['cast'] = cast
    record['fanart'] = _path(t, 'primaryVideos', 'edges', 0, 'node', 'thumbnail', 'url') or ''
    record['has_video'] = bool(_path(t, 'primaryVideos', 'edges', 0, 'node', 'id'))
    return record


def parse_html(page, imdb_id=''):
    """Fallback: the JSON-LD block of an imdb.com title page."""
    ld = {}
    for block in re.findall(r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
                            page, re.S | re.I):
        try:
            data = json.loads(block.strip())
        except ValueError:
            continue
        if isinstance(data, dict) and (data.get('name') or data.get('aggregateRating')):
            ld = data
            break
    if not ld:
        return None

    def people(value):
        value = [value] if isinstance(value, dict) else (value or [])
        return [p.get('name') for p in value
                if isinstance(p, dict) and p.get('@type') == 'Person' and p.get('name')]

    genres = ld.get('genre') or []
    record = {
        'source': 'imdb', 'id': imdb_id,
        'title': strip_tags(str(ld.get('alternateName') or ld.get('name') or '')),
        'originaltitle': strip_tags(str(ld.get('name') or '')),
        'kind': str(ld.get('@type') or ''),
        'year': to_int(str(ld.get('datePublished') or '')[:4]),
        'premiered': str(ld.get('datePublished') or ''),
        'duration': iso_duration(ld.get('duration')),
        'mpaa': str(ld.get('contentRating') or ''),
        'rating': float(_path(ld, 'aggregateRating', 'ratingValue') or 0),
        'votes': to_int(_path(ld, 'aggregateRating', 'ratingCount')),
        'genres': [genres] if isinstance(genres, str) else list(genres),
        'plot': strip_tags(str(ld.get('description') or '')),
        'plot_lang': 'en',
        'tagline': '',
        'poster': str(ld.get('image') or ''),
        'countries': [],
        'directors': people(ld.get('director')),
        'writers': people(ld.get('creator')),
        'cast': [{'name': n, 'role': '', 'thumb': ''} for n in people(ld.get('actor'))],
        'fanart': str(_path(ld, 'trailer', 'thumbnailUrl') or ''),
        'has_video': bool(ld.get('trailer')),
    }
    return record


IMDB_PAGE_HOST = 'www.imdb.com'


def fetch_title(imdb_id, fetch=net.fetch, fetch_json=net.fetch_json):
    if net.host_paused(IMDB_PAGE_HOST):
        raise net.HostDown('IMDb is skipped for now (it refused earlier requests)', code=-1)
    last = None
    for query in (Q_TITLE_FULL, Q_TITLE_SAFE):
        try:
            record = parse_title(graphql(query, {'id': imdb_id}, fetch_json))
            record['id'] = imdb_id
            return record
        except net.FetchError as e:
            last = e
            if e.code == 404:
                raise
            if e.code != 400:      # not a schema problem: do not repeat the call
                break
    try:
        page = fetch('https://www.imdb.com/title/%s/' % imdb_id,
                     headers={'Accept': 'text/html,application/xhtml+xml'})
        record = parse_html(page, imdb_id)
        if record:
            return record
        # neither the API nor the page gave anything: IMDb is turning us away
        last = net.Blocked('IMDb did not give details for %s (bot check?)' % imdb_id, 403,
                           'https://%s/title/%s/' % (IMDB_PAGE_HOST, imdb_id), pause=3 * 3600)
    except net.FetchError as e:
        if e.code == 404 or last is None:
            last = e
    raise last


# --- episodes ----------------------------------------------------------------

def parse_episodes(data, season):
    episodes = {}
    for edge in _path(data, 'title', 'episodes', 'episodes', 'edges') or []:
        node = edge.get('node') or {}
        number = _path(node, 'series', 'displayableEpisodeNumber', 'episodeNumber', 'text')
        shown = _path(node, 'series', 'displayableEpisodeNumber', 'displayableSeason', 'text')
        if number is None or not str(number).isdigit():
            continue
        if shown is not None and str(shown) != str(season):
            continue
        episodes[str(int(number))] = {
            'id': node.get('id') or '',
            'title': _path(node, 'titleText', 'text') or '',
            'plot': (_path(node, 'plot', 'plotText', 'plainText') or '').strip(),
            'plot_lang': 'en',
            'thumb': _path(node, 'primaryImage', 'url') or '',
            'aired': _date(node.get('releaseDate')),
            'duration': to_int(_path(node, 'runtime', 'seconds')),
            'rating': float(_path(node, 'ratingsSummary', 'aggregateRating') or 0),
            'votes': to_int(_path(node, 'ratingsSummary', 'voteCount')),
        }
    return episodes


def fetch_episodes(imdb_id, season, fetch_json=net.fetch_json):
    data = graphql(Q_EPISODES, {'id': imdb_id, 'season': str(season)}, fetch_json)
    return parse_episodes(data, season)


# --- trailers ----------------------------------------------------------------

_DEFINITION = re.compile(r'(\d{3,4})p', re.I)


def parse_trailer(data):
    """Picks the best directly playable file of the title's main video."""
    best = None
    for edge in _path(data, 'title', 'primaryVideos', 'edges') or []:
        node = edge.get('node') or {}
        kind = str(_path(node, 'contentType', 'id') or '')
        for item in node.get('playbackURLs') or []:
            url = item.get('url')
            if not url:
                continue
            mime = str(item.get('videoMimeType') or '').upper()
            label = '%s %s' % (item.get('videoDefinition') or '',
                               _path(item, 'displayName', 'value') or '')
            m = _DEFINITION.search(label)
            height = int(m.group(1)) if m else 0
            # MP4 plays everywhere; adaptive streams are the fallback
            score = (2 if 'MP4' in mime else 1, min(height, 1080))
            if 'trailer' in kind.lower():
                score = (score[0] + 2, score[1])
            if best is None or score > best[0]:
                best = (score, url, mime)
        if best and best[0][0] >= 3:
            break
    if not best:
        return None
    return {'url': best[1], 'mime': best[2]}


def fetch_trailer(imdb_id, fetch_json=net.fetch_json):
    last = None
    for query in (Q_TRAILER_FULL, Q_TRAILER_SAFE):
        try:
            return parse_trailer(graphql(query, {'id': imdb_id}, fetch_json))
        except net.FetchError as e:
            last = e
            if e.code != 400:
                break
    raise last
