# -*- coding: UTF-8 -*-
"""
Small HTTP helper used by all metadata sources.

It deliberately uses its own opener: the rest of the add-on installs global
urllib openers (cookie jars, a no-redirect handler) that must not leak into
metadata requests.
"""

import gzip
import json
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zlib
from http.cookiejar import CookieJar

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36')

# minimum delay between two requests to the same host (seconds); keeps the
# add-on a polite client and avoids rate limiting
MIN_INTERVAL = {
    'www.csfd.cz': 0.25,
    'www.csfd.sk': 0.25,
    'translate.googleapis.com': 0.15,
    'api.mymemory.translated.net': 0.2,
}

# a host that fails this many times in a row is skipped for a while
BREAKER_LIMIT = 4
BREAKER_PAUSE = 600
# a site that answers with a bot check is left alone for much longer
BLOCK_PAUSE = 6 * 3600

# how the add-on introduces itself to sites that sort browsers from programs;
# the Kodi layer fills in the real versions
CLIENT = 'Kodi plugin.video.sosac.ph'

BOT_WALL_MARKERS = ('anubis', 'botstopper', 'within.website', 'oh noes!',
                    "making sure you're not a bot", 'access denied', 'captcha',
                    'cf-browser-verification', 'just a moment...', 'are you a robot')


class FetchError(Exception):

    def __init__(self, message, code=0, url=''):
        Exception.__init__(self, message)
        self.code = code
        self.url = url


class HostDown(FetchError):
    """Raised without touching the network while a host is paused."""


class Blocked(FetchError):
    """The site refuses automated requests (bot check, access denied)."""

    def __init__(self, message, code=403, url='', pause=BLOCK_PAUSE):
        FetchError.__init__(self, message, code, url)
        self.pause = pause


def looks_like_bot_wall(page):
    head = (page or '')[:6000].lower()
    return any(marker in head for marker in BOT_WALL_MARKERS)


def pause(host, seconds):
    """Stop talking to a host for a while. Returns True when this is news."""
    with _guard:
        fresh = _host_paused.get(host, 0) <= time.time()
        _host_paused[host] = time.time() + seconds
        _host_fails[host] = 0
    return fresh


# set by the engine when a listing has used up its time: no more retries
CANCEL = threading.Event()

_guard = threading.Lock()
_host_locks = {}
_host_last = {}
_host_fails = {}
_host_paused = {}
_opener = None


def _get_opener():
    global _opener
    if _opener is None:
        _opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(CookieJar()))
    return _opener


def _host(url):
    return urllib.parse.urlsplit(url).netloc.lower()


def _throttle(host):
    interval = MIN_INTERVAL.get(host)
    if not interval:
        return
    with _guard:
        lock = _host_locks.setdefault(host, threading.Lock())
    with lock:
        wait = _host_last.get(host, 0) + interval - time.time()
        if wait > 0:
            time.sleep(wait)
        _host_last[host] = time.time()


def host_paused(host):
    until = _host_paused.get(host, 0)
    return until > time.time()


def paused_hosts():
    now = time.time()
    return dict((h, t) for h, t in _host_paused.items() if t > now)


def restore_paused(hosts):
    """Used by the engine to carry the breaker state between plugin runs."""
    now = time.time()
    for host, until in (hosts or {}).items():
        try:
            if float(until) > now:
                _host_paused[host] = float(until)
        except (TypeError, ValueError):
            pass


def reset():
    _host_fails.clear()
    _host_paused.clear()


def _note(host, ok):
    with _guard:
        if ok:
            _host_fails[host] = 0
            return
        _host_fails[host] = _host_fails.get(host, 0) + 1
        if _host_fails[host] >= BREAKER_LIMIT:
            _host_paused[host] = time.time() + BREAKER_PAUSE
            _host_fails[host] = 0


def _decode(raw, headers):
    encoding = (headers.get('Content-Encoding') or '').lower()
    if encoding == 'gzip':
        raw = gzip.decompress(raw)
    elif encoding == 'deflate':
        try:
            raw = zlib.decompress(raw)
        except zlib.error:
            raw = zlib.decompress(raw, -zlib.MAX_WBITS)
    charset = None
    try:
        charset = headers.get_content_charset()
    except Exception:
        pass
    return raw.decode(charset or 'utf-8', 'replace')


def fetch(url, data=None, headers=None, timeout=8, retries=1):
    """
    GET (or POST when data is given) and return the body as text.

    data may be bytes, str or a dict (sent as JSON).
    Raises FetchError with the HTTP status in .code (0 = network problem).
    """
    host = _host(url)
    if host_paused(host):
        raise HostDown('%s is temporarily skipped after repeated errors' % host,
                       code=-1, url=url)
    hdrs = {
        'User-Agent': UA,
        'Accept': '*/*',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'en-US,en;q=0.8',
    }
    if isinstance(data, dict):
        data = json.dumps(data).encode('utf-8')
        hdrs['Content-Type'] = 'application/json'
    elif isinstance(data, str):
        data = data.encode('utf-8')
    if headers:
        hdrs.update(headers)

    last = None
    for attempt in range(retries + 1):
        if attempt and CANCEL.is_set():
            break
        _throttle(host)
        try:
            req = urllib.request.Request(url, data=data, headers=hdrs)
            resp = _get_opener().open(req, timeout=timeout)
            try:
                body = _decode(resp.read(), resp.headers)
            finally:
                resp.close()
            _note(host, True)
            return body
        except urllib.error.HTTPError as e:
            detail = ''
            try:
                detail = _decode(e.read(), e.headers)[:300]
            except Exception:
                pass
            last = FetchError('HTTP %d for %s %s' % (e.code, url, detail),
                              code=e.code, url=url)
            # only retry what can plausibly succeed a moment later
            if e.code not in (429, 500, 502, 503, 504):
                break
            time.sleep(0.6 * (attempt + 1))
        except Exception as e:  # URLError, timeout, SSL, bad gzip...
            last = FetchError('%s for %s' % (e, url), code=0, url=url)
            time.sleep(0.3 * (attempt + 1))
    # a plain "not found" or a rejected API key says nothing about the health of the host
    _note(host, last is not None and last.code in (400, 401, 404, 422))
    raise last


def fetch_json(url, data=None, headers=None, timeout=8, retries=1):
    body = fetch(url, data=data, headers=headers, timeout=timeout, retries=retries)
    try:
        return json.loads(body)
    except ValueError:
        raise FetchError('Invalid JSON from %s: %s' % (url, body[:200]), code=0, url=url)
