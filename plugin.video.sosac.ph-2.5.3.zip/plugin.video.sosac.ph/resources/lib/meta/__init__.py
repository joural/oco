# -*- coding: UTF-8 -*-
"""
Metadata engine for plugin.video.sosac.ph.

Looks up plot, ratings, cast, artwork and trailers on CSFD, IMDb and
(optionally) TMDb, translates text between Czech/Slovak/English and keeps
everything in a local cache.

Nothing in this package imports Kodi modules, so it can be run and tested
with a plain Python 3.8+ interpreter (see selftest.py).
"""

__version__ = '1.0.0'
