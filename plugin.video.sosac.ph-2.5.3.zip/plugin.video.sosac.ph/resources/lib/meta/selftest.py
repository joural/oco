# -*- coding: UTF-8 -*-
"""
Command line check of the metadata engine, no Kodi needed:

    python selftest.py                      (The Shawshank Redemption, Slovak)
    python selftest.py --lang en
    python selftest.py --imdb tt0903747 --csfd 234260 --tv --tmdb-key YOURKEY
    python selftest.py --imdb "" --csfd "" --title "Inception" --year 2010 --tmdb-key YOURKEY

Prints what every source returned and the merged result.
"""

import argparse
import json
import os
import sys

if __package__ in (None, ''):
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from meta.engine import Engine, make_ref   # noqa: E402
else:
    from .engine import Engine, make_ref


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--imdb', default='tt0111161')
    parser.add_argument('--csfd', default='2294')
    parser.add_argument('--lang', default='sk', choices=['sk', 'cs', 'en'])
    parser.add_argument('--source', default='auto', choices=['auto', 'csfd', 'imdb'])
    parser.add_argument('--translator', default='google', choices=['google', 'deepl', 'mymemory'])
    parser.add_argument('--deepl-key', default='')
    parser.add_argument('--tmdb-key', default='')
    parser.add_argument('--title', default='', help='Sosac title (used to search TMDb)')
    parser.add_argument('--year', type=int, default=0)
    parser.add_argument('--tv', action='store_true', help='the ids belong to a TV show')
    parser.add_argument('--season', type=int, default=0, help='also list this season')
    args = parser.parse_args(argv)

    engine = Engine({'lang': args.lang, 'plot_source': args.source, 'translator': args.translator,
                     'deepl_key': args.deepl_key, 'tmdb_key': args.tmdb_key},
                    log=lambda msg: print('  [log] %s' % msg))
    print('== services')
    ok = True
    for name, good, detail in engine.diagnose(args.imdb, args.csfd):
        ok &= good
        print('  %-28s %-5s %s' % (name, 'OK' if good else 'FAIL', detail))

    ref = make_ref(args.imdb, args.csfd, 'tvshow' if args.tv else 'movie', args.title, args.year)
    info, _ = engine.resolve(ref)
    print('== merged result (%s)' % args.lang)
    print(json.dumps(info, indent=2, ensure_ascii=False))
    if args.season:
        episodes, _ = engine.episodes(ref, args.season)
        print('== season %d: %d episodes' % (args.season, len(episodes)))
        for number in sorted(episodes, key=int):
            print('  %2s  %s' % (number, episodes[number].get('title')))
    print('== trailer')
    print(json.dumps(engine.trailer(ref), indent=2))
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
