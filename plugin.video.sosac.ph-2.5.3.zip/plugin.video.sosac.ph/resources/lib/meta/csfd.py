# -*- coding: UTF-8 -*-
"""
CSFD (csfd.cz / csfd.sk) scraper.

CSFD has no public API, so this reads the film page. Every field is parsed
independently and from two places where possible (the embedded schema.org
JSON-LD block and the visible HTML), so a layout change costs one field
rather than the whole record.
"""

import json
import re

from . import net
from .textutil import strip_tags, to_int, iso_duration, detect_cs_sk

DOMAINS = {'cs': 'www.csfd.cz', 'sk': 'www.csfd.sk'}

_LABELS = {
    'directors': ('režie', 'réžia', 'rezie', 'rezia'),
    'writers': ('scénář', 'scenár', 'scenar'),
    'cast': ('hrají', 'hrajú', 'hraji', 'hraju'),
}


def normalize_id(raw):
    """'2294', 2294, '2294-vykoupeni...' or a csfd URL -> '2294' (or None)."""
    if raw is None:
        return None
    text = str(raw).strip()
    m = re.search(r'/film/(\d+)', text) or re.match(r'^(\d+)', text)
    if not m:
        return None
    value = m.group(1).lstrip('0')
    return value or None


def url_for(csfd_id, lang='cs'):
    # the bare id redirects to the full "id-slug/prehled" address
    return 'https://%s/film/%s/' % (DOMAINS.get(lang, DOMAINS['cs']), csfd_id)


def fetch_title(csfd_id, lang='cs', fetch=None):
    """
    Reads one film page.

    CSFD protects itself against automated traffic. The request therefore says
    plainly what it is (no browser disguise) and a refusal is taken as final:
    net.Blocked is raised and the engine leaves the site alone for hours.
    Nothing here tries to get around the check.
    """
    fetch = fetch or net.fetch
    url = url_for(csfd_id, lang)
    try:
        page = fetch(url, retries=0,
                     headers={'User-Agent': net.CLIENT,
                              'Accept-Language': 'sk,cs;q=0.9,en;q=0.5' if lang == 'sk'
                              else 'cs,sk;q=0.9,en;q=0.5',
                              'Accept': 'text/html,application/xhtml+xml'})
    except net.HostDown:
        raise
    except net.FetchError as e:
        if e.code in (401, 403, 451):
            raise net.Blocked('CSFD refuses automated requests (HTTP %d)' % e.code, e.code, url)
        if e.code == 429:
            raise net.Blocked('CSFD asks to slow down (HTTP 429)', 429, url, pause=900)
        raise
    record = parse(page)
    if not is_film(record):
        if net.looks_like_bot_wall(page):
            raise net.Blocked('CSFD answered with its bot check instead of the film page',
                              403, url)
        raise net.FetchError('CSFD page for %s could not be understood (layout change?)'
                             % csfd_id, code=0, url=url)
    record['id'] = str(csfd_id)
    record['url'] = url
    record['site'] = lang
    return record


def is_film(record):
    """A real film page gives a title plus at least one more fact."""
    return bool(record.get('title')) and any(
        record.get(field) for field in ('rating', 'plot', 'genres', 'year', 'cast', 'directors'))


# --- parsing -----------------------------------------------------------------

def _jsonld(page):
    for block in re.findall(r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
                            page, re.S | re.I):
        try:
            data = json.loads(block.strip())
        except ValueError:
            continue
        candidates = data if isinstance(data, list) else [data]
        if isinstance(data, dict) and isinstance(data.get('@graph'), list):
            candidates = data['@graph']
        for item in candidates:
            if not isinstance(item, dict):
                continue
            kind = item.get('@type')
            kind = ' '.join(kind) if isinstance(kind, list) else str(kind)
            if re.search(r'Movie|TVSeries|TVSeason|TVEpisode|CreativeWork', kind) or \
                    'aggregateRating' in item:
                return item
    return {}


def _names(value):
    if isinstance(value, dict):
        value = [value]
    out = []
    for person in value or []:
        name = person.get('name') if isinstance(person, dict) else person
        if name and str(name).strip() not in out:
            out.append(str(name).strip())
    return out


def _first(pattern, text, flags=re.S | re.I):
    m = re.search(pattern, text, flags)
    return m.group(1) if m else ''


def _image(url):
    if not url or url.startswith('data:'):
        return ''
    if url.startswith('//'):
        url = 'https:' + url
    if 'poster-free' in url or '/assets/' in url:
        return ''
    # drop the thumbnail resizer to get the full poster
    return re.sub(r'/cache/resized/[^/]+/', '/', url)


def _creators(page):
    out = {'directors': [], 'writers': [], 'cast': []}
    start = page.find('class="creators')
    if start < 0:
        return out
    window = page[start:start + 40000]
    for m in re.finditer(r'<h4[^>]*>(.*?)</h4>(.*?)(?=<h4|</div|</section|<section|$)', window, re.S | re.I):
        label = strip_tags(m.group(1)).strip(' :').lower()
        for field, labels in _LABELS.items():
            if label in labels:
                names = []
                for a in re.finditer(r'<a\b([^>]*)>(.*?)</a>', m.group(2), re.S | re.I):
                    attrs, text = a.group(1), strip_tags(a.group(2))
                    if not text or re.search(r'class="[^"]*\bmore\b', attrs):
                        continue
                    if not re.search(r'href="[^"]*/tv[uo]r[^"/]*/', attrs):
                        continue
                    if text not in names:
                        names.append(text)
                out[field] = names
    return out


def _plot(page):
    for pattern in (r'<div[^>]+class="[^"]*\bplot-full\b[^"]*"[^>]*>(.*?)</div>',
                    r'<div[^>]+class="[^"]*\bplot-preview\b[^"]*"[^>]*>(.*?)</div>',
                    r'<div[^>]+class="[^"]*\bbody--plots\b[^"]*"[^>]*>(.*?)</div>'):
        fragment = _first(pattern, page)
        if not fragment:
            continue
        # the source of the text ("(distributor)") and "more" links are not plot
        fragment = re.sub(r'<em[^>]*>.*?</em>', '', fragment, flags=re.S | re.I)
        fragment = re.sub(r'<a[^>]+class="[^"]*\b(?:more|user-title-name)\b[^"]*"[^>]*>.*?</a>', '',
                          fragment, flags=re.S | re.I)
        text = strip_tags(fragment)
        text = re.sub(r'\s*\((?:více|viac)\)\s*$', '', text).strip()
        if len(text) > 15:
            return text
    return ''


def _origin(page):
    """'USA / Velká Británie, 1994, 142 min' -> countries, year, seconds."""
    text = strip_tags(_first(r'<div[^>]+class="[^"]*\borigin\b[^"]*"[^>]*>(.*?)</div>', page))
    text = text.replace('\n', ' ')
    countries, year, duration = [], 0, 0
    if not text:
        return countries, year, duration
    m = re.search(r'\b(1[89]\d\d|20\d\d)\b', text)
    if m:
        year = int(m.group(1))
    head = re.split(r'[,(]?\s*\(?\b(?:1[89]\d\d|20\d\d)\b', text)[0]
    for part in re.split(r'\s*/\s*|\s*,\s*', head):
        part = part.strip(' ,(')
        if part and not re.search(r'\d', part) and part not in countries:
            countries.append(part)
    # series pages give the total running time plus "(Minutáž: 43-58 min)"
    m = re.search(r'Minut[áa]ž:?\s*(\d+)', text, re.I)
    if m:
        duration = int(m.group(1)) * 60
    elif not re.search(r'\d+\s*h\b', text):
        m = re.search(r'(\d+)\s*min', text)
        if m:
            duration = int(m.group(1)) * 60
    return countries, year, duration


def _other_titles(page):
    """Returns (original title, {country: title}) from the list of names."""
    block = _first(r'<ul[^>]+class="[^"]*\bfilm-names\b[^"]*"[^>]*>(.*?)</ul>', page)
    titles, original = {}, ''
    for li in re.findall(r'<li[^>]*>(.*?)</li>', block, re.S | re.I):
        country = _first(r'<img[^>]+title="([^"]*)"', li) or _first(r'<img[^>]+alt="([^"]*)"', li)
        li = re.sub(r'<span[^>]+class="[^"]*\bmore-info\b[^"]*"[^>]*>.*?</span>', '', li,
                    flags=re.S | re.I)
        li = re.sub(r'<a[^>]+class="[^"]*\bmore\b[^"]*"[^>]*>.*?</a>', '', li, flags=re.S | re.I)
        name = strip_tags(li).strip()
        name = re.sub(r'\s*\((?:více|viac|více názvů|viac názvov)\)\s*$', '', name).strip()
        if not name:
            continue
        if not original:
            original = name
        if country:
            titles.setdefault(strip_tags(country), name)
    return original, titles


def parse(page):
    ld = _jsonld(page)
    record = {'source': 'csfd'}

    # title
    header = _first(r'<div[^>]+class="[^"]*\bfilm-header-name\b[^"]*"[^>]*>(.*?)</div>', page)
    # only the heading of the film header counts: any other <h1> belongs to some other page
    h1 = _first(r'<h1[^>]*>(.*?)</h1>', header) if header else ''
    h1 = re.sub(r'<span[^>]+class="[^"]*\btype\b[^"]*"[^>]*>.*?</span>', '', h1, flags=re.S | re.I)
    record['title'] = strip_tags(h1).replace('\n', ' ').strip() or str(ld.get('name') or '').strip()

    original, by_country = _other_titles(page)
    record['originaltitle'] = original
    record['titles'] = by_country

    # rating (CSFD uses percent) -> 0..10
    percent = _first(r'class="[^"]*\bfilm-rating-average\b[^"]*"[^>]*>\s*(\d{1,3})\s*%', page)
    rating = 0.0
    if percent:
        rating = int(percent) / 10.0
    else:
        agg = ld.get('aggregateRating') or {}
        try:
            value = float(str(agg.get('ratingValue')).replace(',', '.'))
            best = float(agg.get('bestRating') or (100 if value > 10 else 10))
            rating = round(value / best * 10.0, 1) if best else 0.0
        except (TypeError, ValueError):
            rating = 0.0
    record['rating'] = rating
    votes = to_int((ld.get('aggregateRating') or {}).get('ratingCount'))
    if not votes:
        votes = to_int(re.sub(r'\D', '', _first(
            r'class="[^"]*\bratings-btn\b[^"]*".*?<span[^>]+class="[^"]*\bcounter\b[^"]*"[^>]*>'
            r'\(([^)]*)\)', page)))
    record['votes'] = votes

    # genres
    genres = []
    for part in strip_tags(_first(r'<div[^>]+class="[^"]*\bgenres\b[^"]*"[^>]*>(.*?)</div>',
                                  page)).split('/'):
        part = part.strip()
        if part and part not in genres:
            genres.append(part)
    if not genres:
        value = ld.get('genre') or []
        genres = [g.strip() for g in ([value] if isinstance(value, str) else value) if g]
    record['genres'] = genres

    countries, year, duration = _origin(page)
    record['countries'] = countries
    record['year'] = year or to_int(str(ld.get('dateCreated') or ld.get('datePublished') or '')[:4])
    record['duration'] = duration or iso_duration(ld.get('duration'))

    creators = _creators(page)
    record['directors'] = creators['directors'] or _names(ld.get('director'))
    record['writers'] = creators['writers'] or _names(ld.get('author') or ld.get('creator'))
    record['cast'] = [{'name': n} for n in (creators['cast'] or _names(ld.get('actor')))]

    plot = _plot(page)
    if not plot:
        plot = strip_tags(str(ld.get('description') or ''))
    record['plot'] = plot
    record['plot_lang'] = detect_cs_sk(plot) or 'cs'

    poster = ''
    posters = _first(r'<div[^>]+class="[^"]*\bfilm-posters\b[^"]*"[^>]*>(.*?)</div>', page)
    if posters:
        srcset = _first(r'<img[^>]+srcset="([^"]+)"', posters)
        if srcset:
            poster = _image(srcset.split(',')[-1].strip().split(' ')[0])
        poster = poster or _image(_first(r'<img[^>]+src="([^"]+)"', posters))
    if not poster:
        image = ld.get('image')
        if isinstance(image, dict):
            image = image.get('url')
        if isinstance(image, list):
            image = image[0] if image else ''
        poster = _image(str(image or ''))
    record['poster'] = poster
    return record
