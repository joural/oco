# -*- coding: UTF-8 -*-
"""
Machine translation between Slovak, Czech and English.

Three interchangeable back-ends:
  google    - the free endpoint Google's own web widgets use (no key)
  deepl     - DeepL API, needs the user's key (free keys end with ":fx")
  mymemory  - MyMemory public API (no key, small daily allowance)
"""

import hashlib
import json
import urllib.parse

from . import net
from .textutil import split_sentences

ENGINES = ('google', 'deepl', 'mymemory')


class Translator(object):

    def __init__(self, engine='google', deepl_key='', cache=None,
                 fetch=net.fetch, fetch_json=net.fetch_json):
        self.engine = engine if engine in ENGINES else 'google'
        self.deepl_key = (deepl_key or '').strip()
        if self.engine == 'deepl' and not self.deepl_key:
            self.engine = 'google'
        self.cache = cache
        self.fetch = fetch
        self.fetch_json = fetch_json

    def key(self, text, src, dst):
        digest = hashlib.sha1(text.encode('utf-8')).hexdigest()
        return 'tr:%s:%s:%s:%s' % (self.engine, src, dst, digest)

    def cached(self, text, src, dst):
        if not self.cache:
            return None
        return self.cache.get(self.key(text, src, dst))

    def translate(self, text, src, dst):
        """Returns translated text; raises net.FetchError when it cannot."""
        text = (text or '').strip()
        if not text or src == dst:
            return text
        hit = self.cached(text, src, dst)
        if hit:
            return hit
        result = getattr(self, '_' + self.engine)(text, src, dst)
        result = (result or '').strip()
        if not result:
            raise net.FetchError('Empty translation from %s' % self.engine)
        if self.cache:
            self.cache.set(self.key(text, src, dst), result)
        return result

    # -- back-ends -------------------------------------------------------

    def _google(self, text, src, dst):
        out = []
        for chunk in split_sentences(text, 1200):
            query = urllib.parse.urlencode({'client': 'gtx', 'sl': src, 'tl': dst,
                                            'dt': 't', 'q': chunk})
            data = self.fetch_json('https://translate.googleapis.com/translate_a/single?' + query)
            try:
                out.append(''.join(seg[0] for seg in data[0] if seg and seg[0]))
            except (TypeError, IndexError, KeyError):
                raise net.FetchError('Unexpected reply from Google Translate')
        return ' '.join(part.strip() for part in out)

    def _deepl(self, text, src, dst):
        host = 'api-free.deepl.com' if self.deepl_key.endswith(':fx') else 'api.deepl.com'
        target = {'en': 'EN-GB', 'sk': 'SK', 'cs': 'CS'}.get(dst, dst.upper())
        body = {'text': [text], 'target_lang': target, 'source_lang': src.upper()}
        data = self.fetch_json('https://%s/v2/translate' % host,
                               data=json.dumps(body).encode('utf-8'),
                               headers={'Authorization': 'DeepL-Auth-Key ' + self.deepl_key,
                                        'Content-Type': 'application/json'})
        try:
            return data['translations'][0]['text']
        except (TypeError, IndexError, KeyError):
            raise net.FetchError('Unexpected reply from DeepL')

    def _mymemory(self, text, src, dst):
        out = []
        for chunk in split_sentences(text, 450):
            query = urllib.parse.urlencode({'q': chunk, 'langpair': '%s|%s' % (src, dst)})
            data = self.fetch_json('https://api.mymemory.translated.net/get?' + query)
            status = str(data.get('responseStatus'))
            translated = (data.get('responseData') or {}).get('translatedText') or ''
            if status != '200' or not translated or 'MYMEMORY WARNING' in translated:
                raise net.FetchError('MyMemory: %s' % (data.get('responseDetails') or status),
                                     code=429 if status == '429' else 0)
            out.append(translated)
        return ' '.join(part.strip() for part in out)
