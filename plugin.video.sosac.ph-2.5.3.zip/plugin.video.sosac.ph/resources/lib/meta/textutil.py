# -*- coding: UTF-8 -*-
"""Text helpers: HTML clean-up, Czech/Slovak detection, genre names."""

import html
import re

_TAG_RE = re.compile(r'<[^>]+>')
_WS_RE = re.compile(r'[ \t\r\f\v\xa0]+')
_BR_RE = re.compile(r'<\s*br\s*/?\s*>|</p\s*>', re.I)


def strip_tags(fragment):
    """HTML fragment -> plain text (keeps paragraph breaks)."""
    if not fragment:
        return ''
    text = _BR_RE.sub('\n', fragment)
    text = _TAG_RE.sub('', text)
    text = html.unescape(text)
    text = _WS_RE.sub(' ', text)
    lines = [line.strip() for line in text.split('\n')]
    return '\n'.join(line for line in lines if line).strip()


def to_text(value):
    """bytes/None/anything -> str (the add-on still passes bytes around)."""
    if value is None:
        return ''
    if isinstance(value, bytes):
        return value.decode('utf-8', 'replace')
    return str(value)


def to_int(value, default=0):
    try:
        return int(float(str(value).replace('\xa0', '').replace(' ', '').replace(',', '.')))
    except (TypeError, ValueError):
        return default


def iso_duration(value):
    """ISO 8601 duration (PT2H22M, PT142M) -> seconds, 0 when unknown."""
    if not value:
        return 0
    m = re.match(r'^P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$', str(value).strip())
    if not m:
        return 0
    d, h, mi, s = [int(x) if x else 0 for x in m.groups()]
    return ((d * 24 + h) * 60 + mi) * 60 + s


# --- Czech / Slovak detection ------------------------------------------------

_CS_CHARS = set('ěřůĚŘŮ')
_SK_CHARS = set('äľĺŕôĽĹŔÔ')
_CS_WORDS = set('''se který která které kteří když jsou byl byla jeho její nebo ještě
    také protože však něco někdo jejich mezi aby už při pro před přes být bude
    není jsem jsme mu ho ze ve své svého svou svým jako ale že tak co'''.split())
_SK_WORDS = set('''sa ktorý ktorá ktoré ktorí keď sú bol bola jeho jej alebo ešte
    tiež pretože však niečo niekto ich medzi aby už pri pre pred cez byť bude
    nie som sme mu ho zo vo svoje svojho svoju svojím ako ale že tak čo'''.split())
# words shared by both languages tell us nothing
_CS_ONLY = _CS_WORDS - _SK_WORDS
_SK_ONLY = _SK_WORDS - _CS_WORDS
_WORD_RE = re.compile(r'[^\W\d_]+', re.U)


def detect_cs_sk(text):
    """Returns 'cs', 'sk' or None when the text gives no clear signal."""
    if not text:
        return None
    cs = sum(2 for ch in text if ch in _CS_CHARS)
    sk = sum(2 for ch in text if ch in _SK_CHARS)
    for word in _WORD_RE.findall(text.lower()):
        if word in _CS_ONLY:
            cs += 1
        elif word in _SK_ONLY:
            sk += 1
    if cs == sk:
        return None
    return 'cs' if cs > sk else 'sk'


# --- genres ------------------------------------------------------------------

# (English, Czech, Slovak)
_GENRES = [
    ('Action', 'Akční', 'Akčný'),
    ('Adventure', 'Dobrodružný', 'Dobrodružný'),
    ('Animation', 'Animovaný', 'Animovaný'),
    ('Anthology', 'Povídkový', 'Poviedkový'),
    ('Biography', 'Životopisný', 'Životopisný'),
    ('Comedy', 'Komedie', 'Komédia'),
    ('Crime', 'Krimi', 'Krimi'),
    ('Dance', 'Taneční', 'Tanečný'),
    ('Disaster', 'Katastrofický', 'Katastrofický'),
    ('Documentary', 'Dokumentární', 'Dokumentárny'),
    ('Drama', 'Drama', 'Dráma'),
    ('Educational', 'Naučný', 'Náučný'),
    ('Entertainment', 'Zábavný', 'Zábavný'),
    ('Erotic', 'Erotický', 'Erotický'),
    ('Experimental', 'Experimentální', 'Experimentálny'),
    ('Fairy Tale', 'Pohádka', 'Rozprávka'),
    ('Family', 'Rodinný', 'Rodinný'),
    ('Fantasy', 'Fantasy', 'Fantasy'),
    ('Film-Noir', 'Film-Noir', 'Film-Noir'),
    ('Game-Show', 'Soutěžní', 'Súťažný'),
    ('History', 'Historický', 'Historický'),
    ('Horror', 'Horor', 'Horor'),
    ('Music', 'Hudební', 'Hudobný'),
    ('Musical', 'Muzikál', 'Muzikál'),
    ('Mystery', 'Mysteriózní', 'Mysteriózny'),
    ('News', 'Publicistický', 'Publicistický'),
    ('Parable', 'Podobenství', 'Podobenstvo'),
    ('Poetic', 'Poetický', 'Poetický'),
    ('Psychological', 'Psychologický', 'Psychologický'),
    ('Puppet', 'Loutkový', 'Bábkový'),
    ('Reality-TV', 'Reality-TV', 'Reality-TV'),
    ('Road Movie', 'Road movie', 'Road movie'),
    ('Romance', 'Romantický', 'Romantický'),
    ('Sci-Fi', 'Sci-Fi', 'Sci-Fi'),
    ('Short', 'Krátkometrážní', 'Krátkometrážny'),
    ('Sport', 'Sportovní', 'Športový'),
    ('Stand-up', 'Stand-up', 'Stand-up'),
    ('Talk-Show', 'Talk-show', 'Talk-show'),
    ('Telenovela', 'Telenovela', 'Telenovela'),
    ('Thriller', 'Thriller', 'Thriller'),
    ('War', 'Válečný', 'Vojnový'),
    ('Western', 'Western', 'Western'),
]
_GENRE_ALIASES = {
    'science fiction': 'sci-fi',
    'romantic': 'romance',
    'historical': 'history',
    'musik': 'music',
    'krátkometrážny': 'short',
    'akcni': 'action',
    'akcny': 'action',
    'valecny': 'war',
    'komedia': 'comedy',
}
_COLUMN = {'en': 0, 'cs': 1, 'sk': 2}
_GENRE_INDEX = {}
for _row in _GENRES:
    for _name in _row:
        _GENRE_INDEX.setdefault(_name.lower(), _row)
for _alias, _target in _GENRE_ALIASES.items():
    if _target in _GENRE_INDEX:
        _GENRE_INDEX.setdefault(_alias, _GENRE_INDEX[_target])
# Sosac writes some genres without spaces or hyphens ("realitytv", "scifi")
_GENRE_LETTERS = dict((re.sub(r'[^a-z]', '', _key), _row) for _key, _row in _GENRE_INDEX.items())


def localize_genres(genres, lang):
    """Maps known genre names (any of en/cs/sk) to the wanted language."""
    column = _COLUMN.get(lang, 0)
    out = []
    for genre in genres or []:
        genre = to_text(genre).strip()
        if not genre:
            continue
        row = _GENRE_INDEX.get(genre.lower()) or \
            _GENRE_LETTERS.get(re.sub(r'[^a-z]', '', genre.lower()))
        name = row[column] if row else (genre if genre[:1].isupper() else genre.capitalize())
        if name not in out:
            out.append(name)
    return out


def split_sentences(text, limit):
    """Splits text into chunks of at most `limit` characters on sentence ends."""
    text = text.strip()
    if len(text) <= limit:
        return [text] if text else []
    parts = re.split(r'(?<=[.!?…])\s+|\n+', text)
    chunks, current = [], ''
    for part in parts:
        while len(part) > limit:  # one very long sentence: hard split on spaces
            cut = part.rfind(' ', 0, limit)
            cut = cut if cut > 0 else limit
            if current:
                chunks.append(current)
                current = ''
            chunks.append(part[:cut])
            part = part[cut:].strip()
        if not part:
            continue
        if current and len(current) + 1 + len(part) > limit:
            chunks.append(current)
            current = part
        else:
            current = (current + ' ' + part).strip()
    if current:
        chunks.append(current)
    return chunks
