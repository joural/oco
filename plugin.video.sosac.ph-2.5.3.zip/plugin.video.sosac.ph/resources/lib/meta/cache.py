# -*- coding: UTF-8 -*-
"""
Key/value cache in a single SQLite file (falls back to memory when SQLite
is not usable on the platform).
"""

import json
import threading
import time

try:
    import sqlite3
except ImportError:  # pragma: no cover - some stripped down builds
    sqlite3 = None


class Cache(object):

    def __init__(self, path=None, log=None):
        self._lock = threading.RLock()
        self._mem = {}
        self._db = None
        self._log = log or (lambda msg: None)
        if path and sqlite3 is not None:
            try:
                self._db = sqlite3.connect(path, timeout=10, check_same_thread=False)
                self._db.execute('PRAGMA synchronous=OFF')
                self._db.execute('CREATE TABLE IF NOT EXISTS kv ('
                                 'k TEXT PRIMARY KEY, t INTEGER NOT NULL, v TEXT NOT NULL)')
                self._db.commit()
            except Exception as e:
                self._log('cache: cannot open %s (%s), using memory only' % (path, e))
                self._db = None

    # -- reading ---------------------------------------------------------

    def get_entry(self, key):
        """Returns (timestamp, value) or None."""
        with self._lock:
            if key in self._mem:
                return self._mem[key]
            if self._db is None:
                return None
            try:
                row = self._db.execute('SELECT t, v FROM kv WHERE k=?', (key,)).fetchone()
            except Exception as e:
                self._log('cache: read failed (%s)' % e)
                return None
            if not row:
                return None
            try:
                entry = (row[0], json.loads(row[1]))
            except ValueError:
                return None
            self._mem[key] = entry
            return entry

    def get(self, key, max_age=None):
        entry = self.get_entry(key)
        if entry is None:
            return None
        if max_age is not None and time.time() - entry[0] > max_age:
            return None
        return entry[1]

    def preload(self, keys):
        """Reads many keys with as few queries as possible."""
        keys = [k for k in set(keys) if k not in self._mem]
        if not keys or self._db is None:
            return
        with self._lock:
            try:
                for i in range(0, len(keys), 400):
                    chunk = keys[i:i + 400]
                    marks = ','.join('?' * len(chunk))
                    for k, t, v in self._db.execute(
                            'SELECT k, t, v FROM kv WHERE k IN (%s)' % marks, chunk):
                        try:
                            self._mem[k] = (t, json.loads(v))
                        except ValueError:
                            pass
            except Exception as e:
                self._log('cache: preload failed (%s)' % e)

    # -- writing ---------------------------------------------------------

    def set(self, key, value):
        self.set_many({key: value})

    def set_many(self, mapping):
        if not mapping:
            return
        now = int(time.time())
        with self._lock:
            rows = []
            for key, value in mapping.items():
                self._mem[key] = (now, value)
                rows.append((key, now, json.dumps(value, ensure_ascii=False)))
            if self._db is None:
                return
            try:
                self._db.executemany('INSERT OR REPLACE INTO kv (k, t, v) VALUES (?, ?, ?)', rows)
                self._db.commit()
            except Exception as e:
                self._log('cache: write failed (%s)' % e)

    def delete(self, keys):
        if isinstance(keys, str):
            keys = [keys]
        with self._lock:
            for key in keys:
                self._mem.pop(key, None)
            if self._db is None:
                return
            try:
                self._db.executemany('DELETE FROM kv WHERE k=?', [(k,) for k in keys])
                self._db.commit()
            except Exception as e:
                self._log('cache: delete failed (%s)' % e)

    def delete_prefix(self, prefix):
        with self._lock:
            for key in [k for k in self._mem if k.startswith(prefix)]:
                del self._mem[key]
            if self._db is None:
                return
            try:
                like = prefix.replace('\\', '\\\\').replace('%', '\\%').replace('_', '\\_')
                self._db.execute("DELETE FROM kv WHERE k LIKE ? ESCAPE '\\'", (like + '%',))
                self._db.commit()
            except Exception as e:
                self._log('cache: delete failed (%s)' % e)

    def purge_prefix(self, prefix, max_age):
        """Drops entries of one key family that are older than max_age seconds."""
        limit = int(time.time() - max_age)
        with self._lock:
            for key in [k for k, e in self._mem.items() if k.startswith(prefix) and e[0] < limit]:
                del self._mem[key]
            if self._db is None:
                return
            try:
                like = prefix.replace('\\', '\\\\').replace('%', '\\%').replace('_', '\\_')
                self._db.execute("DELETE FROM kv WHERE k LIKE ? ESCAPE '\\' AND t < ?",
                                 (like + '%', limit))
                self._db.commit()
            except Exception as e:
                self._log('cache: purge failed (%s)' % e)

    def purge(self, max_age):
        """Drops everything older than max_age seconds."""
        limit = int(time.time() - max_age)
        with self._lock:
            for key in [k for k, e in self._mem.items() if e[0] < limit]:
                del self._mem[key]
            if self._db is None:
                return
            try:
                self._db.execute('DELETE FROM kv WHERE t < ?', (limit,))
                self._db.commit()
            except Exception as e:
                self._log('cache: purge failed (%s)' % e)

    def clear(self):
        with self._lock:
            self._mem.clear()
            if self._db is None:
                return
            try:
                self._db.execute('DELETE FROM kv')
                self._db.commit()
                self._db.execute('VACUUM')
            except Exception as e:
                self._log('cache: clear failed (%s)' % e)

    def count(self, prefix=''):
        with self._lock:
            if self._db is None:
                return len([k for k in self._mem if k.startswith(prefix)])
            try:
                like = prefix.replace('\\', '\\\\').replace('%', '\\%').replace('_', '\\_')
                return self._db.execute("SELECT COUNT(*) FROM kv WHERE k LIKE ? ESCAPE '\\'",
                                        (like + '%',)).fetchone()[0]
            except Exception:
                return 0

    def close(self):
        with self._lock:
            if self._db is not None:
                try:
                    self._db.close()
                except Exception:
                    pass
                self._db = None
