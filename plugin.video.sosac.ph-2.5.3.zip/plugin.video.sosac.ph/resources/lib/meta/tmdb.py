# -*- coding: UTF-8 -*-
"""
TMDb source (needs the user's own free API key).

Fills in everything Sosac does not send itself: plot, cast, high resolution
artwork, YouTube trailers and episode details. Titles are found by the IMDb
number Sosac sends or, when there is none, by searching for the Sosac title
and year.
"""

import re
import unicodedata
import urllib.parse

from . import net
from .textutil import to_int

API = 'https://api.themoviedb.org/3'
IMG = 'https://image.tmdb.org/t/p/'
LOCALES = {'sk': 'sk-SK', 'cs': 'cs-CZ', 'en': 'en-US'}

# image sizes (Sosac's own pictures are 75x109 posters, far too small)
POSTER_SIZE = 'w780'
FANART_SIZE = 'original'
LANDSCAPE_SIZE = 'w1280'
LOGO_SIZE = 'original'
STILL_SIZE = 'w780'
PROFILE_SIZE = 'h632'


def normalize_title(text):
    """'Avengers: Infinity War' -> 'avengersinfinitywar' (accents and punctuation dropped)."""
    text = unicodedata.normalize('NFKD', str(text or '')).casefold()
    text = ''.join(ch for ch in text if not unicodedata.combining(ch))
    text = re.sub(r'^(the|a|an)\s+', '', text)
    return re.sub(r'[\W_]+', '', text)


def pick_result(results, names, year, kind):
    """
    Chooses the search result that is the film/show Sosac means, or None.

    A wrong match is worse than none (it would show another film's plot and
    poster), so a result is only taken when
      - its title matches one of the Sosac names and the year is within one
        year (or Sosac sends no year), or
      - Sosac sends a year and it is the best-ranked result of exactly that year
        whose title at least contains one of the names.
    """
    wanted = [n for n in (normalize_title(name) for name in names) if n]
    if not wanted:
        return None
    year = to_int(year)
    candidates = []
    for rank, result in enumerate(results or []):
        if kind == 'movie':
            titles = [result.get('title'), result.get('original_title')]
            date = result.get('release_date') or ''
        else:
            titles = [result.get('name'), result.get('original_name')]
            date = result.get('first_air_date') or ''
        found = [normalize_title(t) for t in titles if t]
        result_year = to_int(date[:4])
        exact = any(t in wanted for t in found)
        partial = exact or any((w in t or t in w) and min(len(w), len(t)) >= 4
                               for t in found for w in wanted)
        diff = abs(result_year - year) if year and result_year else None
        if exact and (diff is None or diff <= 1):
            candidates.append((0, diff or 0, rank, result))
        elif partial and diff == 0:
            candidates.append((1, 0, rank, result))
    if not candidates:
        return None
    candidates.sort(key=lambda c: c[:3])
    return candidates[0][3]


def clean_key(key):
    """What people paste: spaces, line breaks, quotes, 'api_key=', 'Bearer ' -> the bare key."""
    key = re.sub(r'\s+', '', str(key or ''))
    key = key.strip('\'"<>')
    key = re.sub(r'^(?:bearer|api_key=|apikey=|key=)', '', key, flags=re.I)
    return key.strip('\'"<>')


def key_problem(key):
    """'' when the key looks like a TMDb key, otherwise what is wrong with it."""
    if not key:
        return 'no API key in Settings > Metadata > TMDb API key'
    if key.startswith('eyJ'):          # v4 "API Read Access Token" (a JWT)
        if key.count('.') != 2 or len(key) < 100:
            return ('the API Read Access Token looks cut off (%d characters, it normally has '
                    'over 200); use the 32-character "API Key" instead' % len(key))
        return ''
    if re.match(r'^[0-9a-f]{32}$', key):
        return ''
    if re.match(r'^[0-9a-fA-F]{32}$', key):
        return ''
    odd = sorted(set(ch for ch in key.lower() if ch not in '0123456789abcdef'))
    return ('this is not a TMDb API key: it has %d characters (a TMDb key has 32)%s. '
            'Copy the "API Key" from themoviedb.org > Settings > API'
            % (len(key), ', and contains "%s" (a TMDb key only has 0-9 and a-f)'
               % ''.join(odd[:6]) if odd else ''))


class KeyRejected(net.FetchError):
    """TMDb answered 401: the API key is wrong or was revoked."""


class TMDb(object):

    def __init__(self, key, fetch_json=net.fetch_json):
        self.key = clean_key(key).lower() if re.match(r'^[0-9a-fA-F]{32}$', clean_key(key)) \
            else clean_key(key)
        self.fetch_json = fetch_json

    def _get(self, path, **params):
        headers = {'Accept': 'application/json'}
        if self.key.startswith('eyJ') or len(self.key) > 40:      # v4 "API Read Access Token"
            headers['Authorization'] = 'Bearer ' + self.key
        else:                       # v3 API key
            params['api_key'] = self.key
        query = urllib.parse.urlencode(dict((k, v) for k, v in params.items() if v is not None))
        try:
            return self.fetch_json('%s%s?%s' % (API, path, query), headers=headers)
        except net.FetchError as e:
            if e.code == 401:
                raise KeyRejected('TMDb rejected the API key (HTTP 401). Check Settings > '
                                  'Metadata > TMDb API key', code=401, url=API)
            raise

    def find(self, imdb_id, mediatype=None):
        """IMDb id -> ('movie'|'tv', tmdb id) or None."""
        data = self._get('/find/' + imdb_id, external_source='imdb_id')
        movies = data.get('movie_results') or []
        shows = data.get('tv_results') or []
        order = [('tv', shows), ('movie', movies)] if mediatype == 'tvshow' \
            else [('movie', movies), ('tv', shows)]
        for kind, results in order:
            if results:
                return kind, str(results[0]['id'])
        return None

    def search(self, names, year=0, mediatype='movie', lang='en'):
        """
        Sosac title(s) + year -> ('movie'|'tv', tmdb id) or None.
        names: every name Sosac knows the title by (English, Czech...).
        """
        kind = 'tv' if mediatype in ('tvshow', 'tv', 'episode') else 'movie'
        year_param = 'first_air_date_year' if kind == 'tv' else 'year'
        names = _unique([str(n).strip() for n in names or [] if n and str(n).strip()])
        year = to_int(year)
        locale = LOCALES.get(lang, 'en-US')
        tried = set()
        # with the year first (precise), then without it (Sosac's year can be off by one)
        for with_year in ([True, False] if year else [False]):
            for name in names:
                key = (normalize_title(name), with_year)
                if not key[0] or key in tried:
                    continue
                tried.add(key)
                params = {'query': name, 'language': locale, 'include_adult': 'false'}
                if with_year:
                    params[year_param] = year
                data = self._get('/search/%s' % kind, **params)
                hit = pick_result(data.get('results'), names, year, kind)
                if hit and hit.get('id'):
                    return kind, str(hit['id'])
        return None

    def title(self, kind, tmdb_id, lang):
        locale = LOCALES.get(lang, 'en-US')
        langs = ','.join(_unique([lang, 'sk', 'cs', 'en']))
        extra = 'credits,videos,images,translations,external_ids,'
        extra += 'release_dates' if kind == 'movie' else 'content_ratings'
        data = self._get('/%s/%s' % (kind, tmdb_id), language=locale,
                         append_to_response=extra,
                         include_image_language=langs + ',null',
                         include_video_language=langs)
        return parse_title(data, kind, lang)

    def season(self, tmdb_id, season, lang):
        locale = LOCALES.get(lang, 'en-US')
        data = self._get('/tv/%s/season/%s' % (tmdb_id, season), language=locale)
        episodes = parse_season(data, lang)
        missing = [n for n, e in episodes.items() if not e['plot']]
        if missing and lang != 'en':
            # fill gaps with the English text so it can still be translated
            english = parse_season(self._get('/tv/%s/season/%s' % (tmdb_id, season),
                                             language='en-US'), 'en')
            for number in missing:
                other = english.get(number)
                if other and other['plot']:
                    episodes[number]['plot'] = other['plot']
                    episodes[number]['plot_lang'] = 'en'
                    if not episodes[number]['title']:
                        episodes[number]['title'] = other['title']
        return episodes


def _unique(values):
    out = []
    for value in values:
        if value and value not in out:
            out.append(value)
    return out


def _img(path, size):
    return IMG + size + path if path else ''


def parse_title(data, kind, lang):
    record = {'source': 'tmdb', 'id': str(data.get('id') or ''), 'kind': kind}
    record['title'] = data.get('title') or data.get('name') or ''
    record['originaltitle'] = data.get('original_title') or data.get('original_name') or ''
    date = data.get('release_date') or data.get('first_air_date') or ''
    record['premiered'] = date
    record['year'] = to_int(date[:4])
    runtime = data.get('runtime') or 0
    if not runtime and data.get('episode_run_time'):
        runtime = data['episode_run_time'][0]
    record['duration'] = to_int(runtime) * 60
    record['rating'] = round(float(data.get('vote_average') or 0), 1)
    record['votes'] = to_int(data.get('vote_count'))
    record['genres'] = [g['name'] for g in data.get('genres') or [] if g.get('name')]
    record['genres_lang'] = lang
    record['countries'] = [c.get('name') for c in data.get('production_countries') or []
                           if c.get('name')]
    record['studios'] = [c['name'] for c in data.get('production_companies') or []
                         if c.get('name')][:3]
    record['status'] = data.get('status') or ''
    record['imdb'] = (data.get('external_ids') or {}).get('imdb_id') or data.get('imdb_id') or ''

    # plot / tagline in every language we may want to show
    plots, taglines = {}, {}
    if data.get('overview'):
        plots[lang] = data['overview'].strip()
    if data.get('tagline'):
        taglines[lang] = data['tagline'].strip()
    for tr in (data.get('translations') or {}).get('translations') or []:
        code = tr.get('iso_639_1')
        if code not in ('sk', 'cs', 'en'):
            continue
        body = tr.get('data') or {}
        if body.get('overview') and code not in plots:
            plots[code] = body['overview'].strip()
        if body.get('tagline') and code not in taglines:
            taglines[code] = body['tagline'].strip()
    # TMDb falls back to English silently; do not label that as translated text
    if lang != 'en' and plots.get(lang) and plots.get(lang) == plots.get('en'):
        translated = [t for t in (data.get('translations') or {}).get('translations') or []
                      if t.get('iso_639_1') == lang and (t.get('data') or {}).get('overview')]
        if not translated:
            del plots[lang]
    record['plots'] = plots
    record['taglines'] = taglines

    # artwork
    images = data.get('images') or {}

    def best(items, fallback):
        ranked = sorted(items or [], key=lambda i: (
            0 if i.get('iso_639_1') == lang else
            1 if i.get('iso_639_1') in ('sk', 'cs') and lang in ('sk', 'cs') else
            2 if i.get('iso_639_1') in (None, 'en', 'xx') else 3,
            -float(i.get('vote_average') or 0)))
        return ranked[0].get('file_path') if ranked else fallback

    record['poster'] = _img(best(images.get('posters'), data.get('poster_path'))
                            or data.get('poster_path'), POSTER_SIZE)
    all_backdrops = images.get('backdrops') or []
    # fanart: a clean picture without any title text on it
    clean = sorted([b for b in all_backdrops if not b.get('iso_639_1')],
                   key=lambda b: -float(b.get('vote_average') or 0))
    record['fanart'] = _img(data.get('backdrop_path') or
                            (clean[0].get('file_path') if clean else ''), FANART_SIZE)
    # landscape: a wide picture with the title on it, in the wanted language if there is one
    titled = [b for b in all_backdrops if b.get('iso_639_1') and b.get('iso_639_1') != 'xx']
    landscape = best(titled, '') if titled else ''
    record['landscape'] = _img(landscape, LANDSCAPE_SIZE) if landscape else ''
    logos = images.get('logos') or []
    record['clearlogo'] = _img(best(logos, ''), LOGO_SIZE) if logos else ''

    # people
    credits = data.get('credits') or {}
    cast = []
    for person in (credits.get('cast') or [])[:20]:
        if person.get('name'):
            cast.append({'name': person['name'], 'role': person.get('character') or '',
                         'thumb': _img(person.get('profile_path'), PROFILE_SIZE)})
    record['cast'] = cast
    crew = credits.get('crew') or []
    record['directors'] = _unique([p.get('name') for p in crew if p.get('job') == 'Director'])
    record['writers'] = _unique([p.get('name') for p in crew
                                 if p.get('department') == 'Writing'])[:4]
    if kind == 'tv' and not record['directors']:
        record['directors'] = _unique([p.get('name') for p in data.get('created_by') or []])

    # trailers (YouTube ids), best match first
    def video_rank(video):
        return (0 if video.get('type') == 'Trailer' else 1 if video.get('type') == 'Teaser' else 2,
                0 if video.get('iso_639_1') == lang else
                1 if video.get('iso_639_1') in ('sk', 'cs') and lang in ('sk', 'cs') else
                2 if video.get('iso_639_1') == 'en' else 3,
                0 if video.get('official') else 1)

    videos = [v for v in (data.get('videos') or {}).get('results') or []
              if v.get('site') == 'YouTube' and v.get('key') and
              v.get('type') in ('Trailer', 'Teaser')]
    record['youtube'] = [v['key'] for v in sorted(videos, key=video_rank)][:3]

    # age rating
    mpaa = ''
    if kind == 'movie':
        for entry in (data.get('release_dates') or {}).get('results') or []:
            if entry.get('iso_3166_1') == 'US':
                for release in entry.get('release_dates') or []:
                    if release.get('certification'):
                        mpaa = release['certification']
                        break
    else:
        for entry in (data.get('content_ratings') or {}).get('results') or []:
            if entry.get('iso_3166_1') == 'US' and entry.get('rating'):
                mpaa = entry['rating']
    record['mpaa'] = mpaa
    return record


def parse_season(data, lang):
    episodes = {}
    for ep in data.get('episodes') or []:
        number = ep.get('episode_number')
        if number is None:
            continue
        episodes[str(int(number))] = {
            'id': str(ep.get('id') or ''),
            'title': ep.get('name') or '',
            'plot': (ep.get('overview') or '').strip(),
            'plot_lang': lang,
            'thumb': _img(ep.get('still_path'), STILL_SIZE),
            'aired': ep.get('air_date') or '',
            'duration': to_int(ep.get('runtime')) * 60,
            'rating': round(float(ep.get('vote_average') or 0), 1),
            'votes': to_int(ep.get('vote_count')),
        }
    return episodes
