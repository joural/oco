# -*- coding: UTF-8 -*-
"""
Local copies of posters, fanart and other pictures.

Kodi downloads a picture only when an item is first shown, which makes
scrolling slow on small devices. The add-on downloads the pictures of a
list page together with its details and hands Kodi the local files.
A picture not used for `keep_hours` is deleted again.
"""

import hashlib
import os
import threading
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from concurrent.futures import TimeoutError as FutureTimeout

from . import net

EXTENSIONS = ('.jpg', '.jpeg', '.png', '.webp')
MAX_BYTES = 15 * 1024 * 1024
CLEANUP_EVERY = 3600


def _looks_like_image(head):
    return (head[:3] == b'\xff\xd8\xff' or head[:8] == b'\x89PNG\r\n\x1a\n' or
            (head[:4] == b'RIFF' and head[8:12] == b'WEBP') or head[:4] == b'GIF8')


class ArtCache(object):

    def __init__(self, folder, keep_hours=24, log=None):
        self.folder = folder
        self.keep = max(1, int(keep_hours or 24)) * 3600
        self.log = log or (lambda msg: None)
        self.ok = False
        if folder:
            try:
                if not os.path.isdir(folder):
                    os.makedirs(folder)
                self.ok = True
            except OSError as e:
                self.log('pictures: cannot use %s (%s)' % (folder, e))

    # -- paths -----------------------------------------------------------

    @staticmethod
    def wanted(url):
        return bool(url) and url.startswith(('http://', 'https://'))

    def path(self, url):
        ext = os.path.splitext(url.split('?', 1)[0])[1].lower()
        if ext not in EXTENSIONS:
            ext = '.jpg'
        name = hashlib.sha1(url.encode('utf-8')).hexdigest()[:24] + ext
        return os.path.join(self.folder, name)

    def local(self, url, touch=True):
        """The local file for url, or None when it has not been downloaded."""
        if not self.ok or not self.wanted(url):
            return None
        path = self.path(url)
        try:
            if os.path.getsize(path) > 0:
                if touch:
                    os.utime(path, None)     # "last used": keeps lists you open often
                return path
        except OSError:
            pass
        return None

    def localize(self, art):
        """Replaces the addresses in an art dict by local files where there are some."""
        return dict((key, self.local(url) or url) for key, url in art.items())

    # -- downloading -----------------------------------------------------

    def _download(self, url, timeout=10):
        path = self.path(url)
        if os.path.exists(path):
            return True
        req = urllib.request.Request(url, headers={'User-Agent': net.UA, 'Accept': 'image/*'})
        resp = net._get_opener().open(req, timeout=timeout)
        try:
            data = resp.read(MAX_BYTES + 1)
        finally:
            resp.close()
        if len(data) > MAX_BYTES or not _looks_like_image(data[:16]):
            raise net.FetchError('not a picture: %s' % url)
        tmp = '%s.%d.part' % (path, threading.get_ident())
        with open(tmp, 'wb') as f:
            f.write(data)
        os.replace(tmp, path)
        return True

    def fetch_many(self, urls, budget=20, workers=6, progress=None):
        """
        Downloads the pictures that are not here yet, in parallel, for at most
        `budget` seconds. Returns the number of pictures downloaded.
        progress: callable(done, total); return False to stop.
        """
        if not self.ok:
            return 0
        todo = []
        for url in urls:
            if self.wanted(url) and url not in todo and not self.local(url):
                todo.append(url)
        if not todo or budget <= 0:
            return 0
        done = ok = 0
        cancel = threading.Event()

        def work(url):
            if cancel.is_set():
                return False
            try:
                return self._download(url)
            except (net.FetchError, urllib.error.URLError, OSError, ValueError) as e:
                self.log('picture %s: %s' % (url, e))
                return False

        if progress:
            progress(0, len(todo))
        pool = ThreadPoolExecutor(max_workers=max(1, min(10, workers)))
        try:
            futures = [pool.submit(work, url) for url in todo]
            try:
                for future in as_completed(futures, timeout=budget):
                    done += 1
                    ok += 1 if future.result() else 0
                    if progress and progress(done, len(todo)) is False:
                        break
            except FutureTimeout:
                self.log('pictures: time is up, %d of %d downloaded; the rest are loaded by '
                         'Kodi when shown' % (ok, len(todo)))
        finally:
            cancel.set()
            pool.shutdown(wait=True)
        return ok

    # -- cleaning up -----------------------------------------------------

    def cleanup(self, force=False):
        """Deletes pictures not used for `keep` seconds (checked at most once an hour)."""
        if not self.ok:
            return 0
        marker = os.path.join(self.folder, '.cleanup')
        now = time.time()
        try:
            if not force and now - os.path.getmtime(marker) < CLEANUP_EVERY:
                return 0
        except OSError:
            pass
        removed = 0
        try:
            for name in os.listdir(self.folder):
                path = os.path.join(self.folder, name)
                if name == '.cleanup':
                    continue
                try:
                    stale = name.endswith('.part') and now - os.path.getmtime(path) > 600
                    if force or stale or now - os.path.getmtime(path) > self.keep:
                        os.remove(path)
                        removed += 1
                except OSError:
                    pass
            with open(marker, 'w') as f:
                f.write(str(int(now)))
        except OSError as e:
            self.log('pictures: cleanup failed (%s)' % e)
        if removed:
            self.log('pictures: deleted %d not used for %d hours' % (removed, self.keep // 3600))
        return removed

    def size(self):
        total = count = 0
        if not self.ok:
            return 0, 0
        for name in os.listdir(self.folder):
            if name.endswith(EXTENSIONS):
                count += 1
                try:
                    total += os.path.getsize(os.path.join(self.folder, name))
                except OSError:
                    pass
        return count, total
