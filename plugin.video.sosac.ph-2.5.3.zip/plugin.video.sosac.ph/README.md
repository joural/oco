# plugin.video.sosac.ph

**Kodi Addon for movies and tv shows**

 - Watch online movies and tv shows from www.sosac.tv.
 - This addon updated for Kodi 19 Matrix with python3
## Metadata (since 2.1.0)

Movie, TV show and episode lists are proper Kodi listings: content type,
plot, genres, cast, ratings, posters/fanart, trailer button, info dialog.
Everything is configured on the **Metadata** page of the add-on settings.

Where the data comes from (in this order)

1. **Sosac** itself: title, year, genres, dubbing, quality, the description
   of TV shows and the ČSFD / IMDb numbers.
2. **TMDb** for everything Sosac does not send: plot, cast, high resolution
   posters / fanart / logos, episode details and YouTube trailers. Needs
   your own free API key: create an account on themoviedb.org, then
   Settings > API, and enter the "API Key" (or the longer "API Read Access
   Token") in Settings > Metadata > **TMDb API key**.
3. **ČSFD and IMDb** fill whatever is still missing (both can be switched off).

| Source | Gives | Needs |
| --- | --- | --- |
| Sosac | title, year, genres, Sosac rating, TV show description | nothing |
| ČSFD (csfd.cz / csfd.sk) | Czech/Slovak plot, genres, ČSFD rating, poster | nothing, but ČSFD turns automated requests away with a bot check. The add-on says honestly what it is, accepts a refusal and leaves the site alone for six hours. It does not try to get around the check. |
| IMDb | English plot, cast with photos, IMDb rating, runtime, trailer video | nothing (unofficial interface, may change) |
| TMDb | plot (Czech, some Slovak, English), cast, HD poster (780 px), fanart (original size), landscape and logo art, episode details and stills, YouTube trailers | your own free API key from themoviedb.org (Settings > API) |

Language: Slovak, Czech or English. Text that is not available in the chosen
language is machine translated (Google by default, DeepL with your key, or
MyMemory). Genre names are translated from a built-in table.

Films are looked up by the IMDb number Sosac sends with its lists. When
there is none (or TMDb does not know it), the add-on searches TMDb for the
Sosac title (English and Czech name) and year. To avoid showing another
film's details, a search result is only taken when its title matches and
its year is within one year of Sosac's. This search can be switched off
("Find titles without an IMDb number on TMDb by name and year").

Settings > Metadata > **Artwork quality** sets the picture sizes: Fast
(342 px posters, 780 px fanart; for Raspberry Pi), Balanced (500 / 1280 px,
default) or Best (original sizes; slow on small devices, since Kodi downloads
and shrinks every picture the first time an item is shown).

The pictures of a list page are downloaded together with its details (the
"Downloading pictures" notification) and Kodi is given the local files, so
scrolling does not wait for downloads. They are kept in the add-on's
`pictures` folder and deleted when not used for 24 hours (Settings >
Metadata, 1-168 hours). A page with 40 films takes roughly 5-20 MB at
Balanced quality.

Sosac's own pictures (75x109 px for movies) are too small for posters or
fanart, so they are only used as the list icon when nothing was found online.

Trailers

Trailers are YouTube videos found on TMDb and are played through
[SendToKodi](https://github.com/firsttris/plugin.video.sendtokodi), which
uses yt-dlp: `plugin://plugin.video.sendtokodi/?url=<encoded YouTube link>`.
SendToKodi is not in the official Kodi repository; install
`repository.sendtokodi` from its GitHub page (Add-ons > Install from zip
file), then install SendToKodi from that repository. If YouTube playback
stops working, switch SendToKodi's yt-dlp channel to Nightly in its settings.
Current yt-dlp needs Python 3.10 or newer. On Kodi builds with an older
Python (e.g. older LibreELEC / OSMC) SendToKodi cannot play YouTube; the
add-on notices this and uses the YouTube add-on instead when it is installed.

Settings > Metadata > **Play trailers with** can choose the YouTube add-on
instead; whichever of the two is installed is used if the chosen one is
missing. With neither installed, IMDb's own trailer video is played when
there is one. The trailer address is also given to Kodi as the item's
trailer, so the skin's Trailer button works.

Everything downloaded is kept in `metadata.db` in the add-on's profile
folder. A list page that has been opened once needs no metadata requests
the next time.

Skins with their own helper (e.g. Nimbus + script.nimbus.helper)

Such helpers look at the focused item and fetch extras for it. Nimbus Helper
fetches ratings (IMDb, TMDb, Trakt, Rotten Tomatoes, Metacritic...) and a
trailer from MDBList, using `ListItem.DBType` and `ListItem.IMDBNumber`. It
does not fetch plot, cast or artwork: the skin shows those from the item.

 - The items of this add-on carry what the helper needs in every mode: the
   media type, the IMDb number (`tt...`), and `Property(imdb)` /
   `Property(tmdb)`. Episodes carry the number of their show.
 - Settings > Metadata > Film details > **Items only** stops all lookups by
   the add-on. Items then hold only what Sosac sends (title, year, genres,
   its small picture, the description of TV shows) and the helper adds
   ratings and trailers. Plot, cast and fanart stay empty in this mode.
 - For plot and artwork as well, keep "Looked up by the add-on" and enter a
   TMDb key; switch "Show ratings above the plot" off, since
   the skin shows ratings itself.

Troubleshooting

 - Settings > Metadata > **Test the sources** asks every source once and
   shows which ones answer.
 - Lines starting with `[plugin.video.sosac.ph metadata]` in kodi.log say
   why a source was skipped.
 - `python resources/lib/meta/selftest.py --lang sk` runs the same check on
   any computer with Python 3.8+ (no Kodi needed).
 - Switching "Show plot, ratings, cast and artwork" off brings back the
   lists exactly as they were in 2.0.0.

## Watch history (since 2.4.0)

The add-on's service follows the Kodi player while a Sosac movie or episode
plays and remembers how far it got (`history.db` in the add-on's profile
folder). Something seen to the end credits (92 % or the last 2.5 minutes)
counts as watched.

 - **Continue watching** (main menu): unfinished movies and episodes, plus
   the next unwatched episode of every show you watched an episode of.
   The next episode is known for shows opened from the TV show lists.
 - **Watch history** (main menu): the last 100 played items.
 - Starting an unfinished item asks whether to resume.
 - Lists show a tick for watched items and the time where unfinished
   ones stopped. Context menu: Mark as watched / unwatched.
 - Settings > Watch history switches it off or deletes it.

## Search (since 2.5.0)

Search finds movies and TV shows together; each result is labelled
**[Film]** or **[Seriál]** (Movie / TV show). Movies come from the usual
Sosac search, TV shows from Sosac's newer API
(`kodi-api.sosac.to/serials/simple-search`, no account needed); a show
opens its usual episode list. If the TV show search is unavailable, movie
results still appear.

